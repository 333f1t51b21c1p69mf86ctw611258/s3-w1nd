/*
 * File: Pane01ScalarRO.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

@SuppressWarnings("serial")
public class PaneAbout extends PaneBase {
    //private static final Logger logger = Logger.getLogger(PaneScalarRO.class);

    private static final String ABOUT = 
        "Welcome to the FriendlySNMP demo!\n" +
        "\n" +
        "The goal of this application is to demo various features of the " +
        "free FriendlySNMP Java library and different techniques how to use it. " +
        "This demo application is provided with Java source code." +
        "\n\n" +
        "You have to configure your MIB browser to match " +
        "the following parameters in the demo.properties " +
        "(or update both, MIB browser and demo.propeties):" +
        "\n  - snmp.address.get-set=127.0.0.1/161" +
        "\n  - snmp.address.send-notification=127.0.0.1/162" +
        "\n  - snmp.v2.community=public" +
        "\n\n" +
        "This demo is a collection of independent tasks which are presented " +
        "in the left pane. Select one of them and play with parameters in " +
        "the right pane." +
        "\n\n" +
        "Some demo tasks have MIB file associated with it. " +
        "These MIBs are very small which helps to learn how to write MIB for " +
        "specific simple SNMP tasks (scalar, table, notification)." +
        "\n\n" +
        "Some demo tasks are supported by FriendlySNMP library and does not " +
        "require any MIB loading. Examples of these tasks are deadlock detection, " +
        "uncaught exception detection, and reporting caught exception." +
        "\n\n" +
        "FriendlySNMP library supports FRIENDLY-SNMP-MIB with extensive " +
        "Java application information and control:" +
        "\n  - application version, title, used libraries" +
        "\n  - application life events like start, stop, shutdown, heartbeat, deadlocks" +
        "\n  - caught and uncaught exceptions" +
        "\n  - persistent storage view" +
        "\n\n" +
        "FriendlySNMP library supports optional JVM plugin which gives " +
        "access via JVM-MANAGEMENT-MIB to JVM parameters: " +
        "class loading, memory, threads, runtime, compilation, OS." +
        "\n\n" +
        "FriendlySNMP library supports optional Log4j plugin to access " +
        "log4j parameters to view / modify loggers and log levels at runtime." +
        "\n";
    
    private JTabbedPane paneTabbed;
    
    @Override
    protected JPanel getContentPanel() {
        paneTabbed = new JTabbedPane();
        paneTabbed.add("About", createPane(ABOUT, FONT_NOTES));
        JPanel p = new JPanel(new BorderLayout());
        p.add(paneTabbed, BorderLayout.CENTER);
        return p;
    } // getContentPanel()
    
    void setProperties(Properties prop) {
        StringBuilder sb = new StringBuilder();
        sb.append("The Demo application was started with the following properties:\n");
        Map<String, String> hm = new TreeMap<String, String>(); // for sorting
        Set<String> hsKey = prop.stringPropertyNames();
        for (String key : hsKey) {
            String val = prop.getProperty(key);
            hm.put(key, val);
        }
        for (Entry<String, String> entry : hm.entrySet()) {
            sb.append(entry.getKey()).append('=').append(entry.getValue()).append('\n');
        }
        paneTabbed.add("Info", createPane(sb.toString(), FONT_CONSOLE));
    } // setProperties()
    
    private JPanel createPane(String text, Font font) {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea ta = new JTextArea();
        ta.setBorder(null);
        ta.setFont(font);
        ta.setBackground(panel.getBackground());
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setEditable(false);
        ta.setText(text);
        ta.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        JScrollPane p = new JScrollPane(ta, 
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel.add(p, BorderLayout.CENTER);
        return panel;
    } // createPane()
    
    @Override
    protected String getNotes() {
        return null; // exclude notes area from the pane
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return null; // to exclude titled border
    } // getTitle()
    
    @Override
    public String toString() {
        return "About & Info"; // to display in the left pane
    } // toString()
    
} // class PaneAbout
