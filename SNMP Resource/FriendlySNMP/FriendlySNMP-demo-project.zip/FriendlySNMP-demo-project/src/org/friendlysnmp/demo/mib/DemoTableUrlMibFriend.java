/*
 * File: DemoTableUrlMibFriend.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo.mib;

import org.friendlysnmp.AgentWorker;
import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FTable;
import org.friendlysnmp.mib.BaseMib;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOServer;
import org.snmp4j.agent.mo.DefaultMOFactory;
import org.snmp4j.smi.OctetString;

public class DemoTableUrlMibFriend extends BaseMib {

    private DemoTableUrlMib mibORIG;

    // Tables
    private FTable urlEntry;

    // Columns for table urlEntry
    public final static FColumn COLUMN_UrlHostName = 
        new FColumn("UrlHostName",
                DemoTableUrlMib.idxUrlHostName, 
                DemoTableUrlMib.colUrlHostName);
    public final static FColumn COLUMN_UrlIpAddress = 
        new FColumn("UrlIpAddress",
                DemoTableUrlMib.idxUrlIpAddress, 
                DemoTableUrlMib.colUrlIpAddress);
    public final static FColumn COLUMN_UrlResponseTime = 
        new FColumn("UrlResponseTime",
                DemoTableUrlMib.idxUrlResponseTime, 
                DemoTableUrlMib.colUrlResponseTime);

    public DemoTableUrlMibFriend() {
        super();
    } // DemoTableUrlMibFriend()

    @Override
    public void init(AgentWorker agent) throws FException {
        super.init(agent);
        mibORIG = new DemoTableUrlMib(DefaultMOFactory.getInstance());
        // Tables
        urlEntry = new FTable("urlEntry", mibORIG.getUrlEntry(), agent,
            COLUMN_UrlHostName,
            COLUMN_UrlIpAddress,
            COLUMN_UrlResponseTime);
        addNode(urlEntry);
    } // init()

    @Override
    public void registerMOs(MOServer server, OctetString context)
    throws DuplicateRegistrationException
    {
        mibORIG.registerMOs(server, context);
    } // registerMOs()

    @Override
    public void unregisterMOs(MOServer server, OctetString context) {
        mibORIG.unregisterMOs(server, context);
    } // unregisterMOs()

    public FTable getUrlEntry() {
        return urlEntry;
    } // getUrlEntry()

} // class DemoTableUrlMibFriend
