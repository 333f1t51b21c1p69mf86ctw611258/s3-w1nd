/*
 * File: TableModelWarehouse.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;

import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FID;
import org.friendlysnmp.FTable;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.TableRowAction;
import org.friendlysnmp.demo.mib.DemoTableWarehouseMib;
import org.friendlysnmp.demo.mib.DemoTableWarehouseMibFriend;
import org.friendlysnmp.event.FRestoreDefaultEvent;
import org.friendlysnmp.event.FRestoreDefaultListener;
import org.friendlysnmp.event.FTableGetListener;
import org.friendlysnmp.event.FTableSetListener;
import org.friendlysnmp.mib.RowStatusTC;

@SuppressWarnings("serial")
public class TableModelWarehouse extends TableModelBase {

    private enum Department {
        APPLIANCES(1), 
        ELECTRONICS (2), 
        SPORTS(3), 
        JEWERLY(4);
        int id;
        Department(int id) {
            this.id = id;
        }
        public static Department find(int n) {
            Department[] a = values();
            for (Department dept : a) {
                if (dept.id == n) {
                    return dept;
                }
            }
            return null;
        }
        public String toString() {
            return super.toString().toLowerCase() + "(" + id + ")";
        }
    } // enum Department
    
    private static class WarehouseRow {
        // Populate with default values
        FID id;
        Department dept;
        String brand = "?";
        String itemName = "?";
        float price = 0;
        WarehouseRow(FID id) {
            // Call from MIB browser
            this.id = id;
            dept = Department.find(id.getInt()[0]);
        }
        WarehouseRow(Department dept, int item) {
            // Call from UI and application init
            this(new FID(dept.id, item)); // department hidden as int in FID
            this.dept = dept;
        }
        Department getDepartment() {
            return dept;
        }
        int getItemIndex() {
            return id.getInt()[1]; // [0]-dept; [1]-item
        }
    } // inner class WarehouseRow
    
    // Column indices
    final static public int COL_DEPARTMENT = 0;
    final static public int COL_ITEM_INDEX = 1;
    final static public int COL_ITEM_BRAND = 2;
    final static public int COL_ITEM_NAME  = 3;
    final static public int COL_ITEM_PRICE = 4;
    final static private int COL_LAST      = 5;

    // Column header names
    final static private String[] HEADERS = new String[COL_LAST];
    static {
        HEADERS[COL_DEPARTMENT] = "Department (index)";
        HEADERS[COL_ITEM_INDEX] = "ID (index)";
        HEADERS[COL_ITEM_BRAND] = "Brand";
        HEADERS[COL_ITEM_NAME ] = "Item";
        HEADERS[COL_ITEM_PRICE] = "Price";
    }

    private List<WarehouseRow> lstRows;

    @Override
    public void updateColumnModel(TableColumnModel columnModel) {
        setColumnFixedWidth(columnModel, COL_DEPARTMENT, 130);
        setColumnFixedWidth(columnModel, COL_ITEM_INDEX, 70);
        setColumnFixedWidth(columnModel, COL_ITEM_BRAND, 70);
        setColumnFixedWidth(columnModel, COL_ITEM_PRICE, 60);
    } // updateColumnModel()
    
    @Override
    public void initSNMP(FriendlyAgent agent) throws FException {
        lstRows = new ArrayList<WarehouseRow>();
        fillDefaultContent();
        
        DemoTableWarehouseMibFriend mib = new DemoTableWarehouseMibFriend();
        agent.addMIB(mib);
        
        table = mib.getWarehouseEntry();
        table.setVolatile(false); // loads persistent value (if exist)
        if (table.isPersistLoaded()) {
            fillPersistContent(table);
        }
        table.addGetListener(new FTableGetListener() {
            @Override
            public void get(FTable table) {
                loadWarehouseTable();
            }
        });
        table.addSetListener(new FTableSetListener() {
            @Override
            public void set(FTable table, FID idRow, FColumn col, TableRowAction action) {
                updateWarehouseTable(idRow, col, action);
            }
        });
        table.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev)
            {
                fillDefaultContent();                
                fireTableDataChanged();
            }
        });
    } // initSNMP()

    private void fillPersistContent(FTable table) {
        lstRows.clear();
        try {
            for (int r = 0;  r < table.getRowCount();  r++) {
                FID idRow = table.getRowID(r);
                Department dept = Department.find(idRow.getInt()[0]);
                if (dept == null) {
                    continue;
                }
                int index = idRow.getInt()[1]; 
                String brand = table.getValueAt(idRow, 
                        DemoTableWarehouseMibFriend.COLUMN_WarehouseItemBrand).toString();
                String itemName = table.getValueAt(idRow, 
                        DemoTableWarehouseMibFriend.COLUMN_WarehouseItemName).toString();
                int price100 = (Integer)table.getValueAt(idRow, 
                        DemoTableWarehouseMibFriend.COLUMN_WarehouseItemPrice);
                fillRow(dept, index, brand, itemName, price100/100f); 
            }
        } catch (FException e) {
        }
        sortRows();        
    }    
    
    private void fillDefaultContent() {
        lstRows.clear();
        fillRow(Department.APPLIANCES, 1, "Whirlpool", "Washer 3.2 CuFt", 549.95f);
        fillRow(Department.APPLIANCES, 3, "Bosch", "Dishwasher 24\"", 578.75f);
        fillRow(Department.ELECTRONICS,4, "Panasonic", "Plasma HDTV 58\"", 2399.99f);
        fillRow(Department.ELECTRONICS,8, "Sony", "Camcorder DVD", 449.99f);
        sortRows();        
    }
    
    private void fillRow(Department dept, int index, String brand, String itemName, float price) {
        WarehouseRow row = new WarehouseRow(dept, index);
        row.brand = brand;
        row.itemName = itemName;
        row.price = price;
        lstRows.add(row);
    } // fillRow()    
    
    public int getColumnCount() {
        // Implements AbstractTableModel
        return HEADERS.length;
    }

    @Override
    public Class<?> getColumnClass(int c) {
        return getValueAt(0, c).getClass(); // to render and edit Float
    }
    
    @Override
    public String getColumnName(int c) {
        table.getColumnCount();
        return HEADERS[c];
    }
    
    public int getRowCount() {
        // Implements AbstractTableModel
        return lstRows.size();
    }

    @Override
    public boolean isCellEditable(int indexRow, int indexCol) {
        switch (indexCol) {
            case COL_DEPARTMENT:
            case COL_ITEM_INDEX: 
                return false;
            case COL_ITEM_BRAND:
            case COL_ITEM_NAME:
            case COL_ITEM_PRICE:
                return true;
            default: 
                throw new IllegalArgumentException("Not valid column: " + indexCol);
        }
    } // isCellEditable()
    
    public Object getValueAt(int r, int c) {
        // Implements AbstractTableModel
        WarehouseRow row = lstRows.get(r);
        switch (c) {
            case COL_DEPARTMENT:
                return row.getDepartment();
            case COL_ITEM_INDEX: 
                return row.getItemIndex();
            case COL_ITEM_BRAND:
                return row.brand;
            case COL_ITEM_NAME:
                return row.itemName;
            case COL_ITEM_PRICE:
                return row.price;
            default: 
                throw new IllegalArgumentException("Not valid column: " + c);
        }
    } // getValueAt()

    @Override
    public void setValueAt(Object val, int r, int c) {
        if (r < 0  ||  r >= lstRows.size()) {
            // See notes in TableModelFlight.setValueAt().
            // This exception is for setting cell value before row is created.
            throw new IllegalArgumentException("Not valid row " + r
                    + " column " + c + " value '" + val + "'");
        }
        WarehouseRow row = lstRows.get(r);
        switch (c) {
            case COL_ITEM_BRAND:
                row.brand = (String)val;
                break;
            case COL_ITEM_NAME:
                row.itemName = (String)val;
                break;
            case COL_ITEM_PRICE:
                row.price = (Float)val;
                row.price = Math.abs(row.price);
                break;
            default: 
                throw new IllegalArgumentException("Not valid column: " + c);
        }
    } // setValueAt()
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int addRow() {
        // Call from UI
        Department[] a_Dept = Department.values();
        Department dept = (Department)JOptionPane.showInputDialog(
                            null,
                            "Make a choice:",
                            "Customized Dialog",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            a_Dept,
                            a_Dept[0]);
        if (dept != null) {
            int index = -1;
            for (WarehouseRow row : lstRows) {
                index = Math.max(index, row.id.getInt()[1]); // second index
            }
            fillRow(dept, index + 1, "?", "?", 0f);        
        }
        return lstRows.size() - 1;
    } // addRow()

    @Override
    public int deleteRow(int indexRow) {
        // Call from UI
        lstRows.remove(indexRow);
        if (indexRow >= lstRows.size()) {
            indexRow--;
        }
        return indexRow;
    } // deleteRow()

    private void loadWarehouseTable() {
        // Call from agent on GET action in MIB browser.
        try {
            table.deleteAll();
            for (WarehouseRow row : lstRows) {
                FID idRow = table.addRow(row.id);
                table.setValueAt(row.brand,    
                        idRow, DemoTableWarehouseMibFriend.COLUMN_WarehouseItemBrand);
                table.setValueAt(row.itemName,    
                        idRow, DemoTableWarehouseMibFriend.COLUMN_WarehouseItemName);
                table.setValueAt((int)(row.price * 100f),    
                        idRow, DemoTableWarehouseMibFriend.COLUMN_WarehouseItemPrice);
                table.setValueAt(
                        RowStatusTC.active, 
                        idRow, DemoTableWarehouseMibFriend.COLUMN_WarehouseRowStatus);
            }
        } catch (FException e) {
            ErrorPresenter.showError(e, 
                    "Failure to update table %s", table.getFIDtoString());
        }
    } // loadWarehouseTable()
    
    private void updateWarehouseTable(FID idRow, FColumn col, TableRowAction action) {
        // Call from agent on SET action in MIB browser.
        // NOTE. Row index in table does not match indexRow in lstRows:
        //   - table object does not have this row after DELETE action.
        //   - table object already has a new row for CREATE action.
        int indexRow = getRowIndex(idRow);
        try {
            switch (action) {
                case ROW_CHANGE:
                    Object obj = table.getValueAt(idRow, col);
                    int nCol = convertMibToColumn(col); 
                    if (obj != null) {
                        if (nCol == COL_ITEM_PRICE) {
                            Integer intValue = (Integer)obj;
                            Float floatValue = new Float((float)intValue / 100f);
                            setValueAt(floatValue, indexRow, nCol);
                        } else {
                            setValueAt(obj, indexRow, nCol);
                        }
                    }
                    break;
                case ROW_CREATE:
                    lstRows.add(new WarehouseRow(idRow));
                    sortRows();        
                    break;
                case ROW_DELETE:
                    lstRows.remove(indexRow);
                    break;
                default: 
                    throw new IllegalArgumentException("Not valid action: " + action);
            }
            fireTableDataChanged();
        } catch (FException e) {
            ErrorPresenter.showError(e,
                    "Failure to set value for cell for Row ID %s, Column %s", 
                    idRow, col);
        }
    } // updateWarehouseTable()
    
    private int convertMibToColumn(FColumn col) {
        switch (col.getIndex_InTable()) {
            case DemoTableWarehouseMib.idxWarehouseItemBrand: return COL_ITEM_BRAND; 
            case DemoTableWarehouseMib.idxWarehouseItemName:  return COL_ITEM_NAME; 
            case DemoTableWarehouseMib.idxWarehouseItemPrice: return COL_ITEM_PRICE; 
            default: 
                throw new IllegalArgumentException("Not valid column: " + col);
        }
    } // convertColumnToMib()

    private int getRowIndex(FID idRow) {
        for (int i = 0;  i < lstRows.size();  i++) {
            WarehouseRow row = lstRows.get(i);
            if (row.id.equals(idRow)) {
                return i;
            }
        }
        return -1;
    } // getRowIndex()
    
    private void sortRows() {
        class WarehouseRowComparator<T> implements Comparator<T> {
            public int compare(T o1, T o2) {
                WarehouseRow row1 = (WarehouseRow)o1;
                WarehouseRow row2 = (WarehouseRow)o2;
                return row1.id.compareTo(row2.id);
            }
        } // inner class WarehouseRowComparator
        final WarehouseRowComparator<WarehouseRow> comp = 
            new WarehouseRowComparator<WarehouseRow>();  
        Collections.sort(lstRows, comp);
    } // sortRows()
    
} // class TableModelWarehouse
