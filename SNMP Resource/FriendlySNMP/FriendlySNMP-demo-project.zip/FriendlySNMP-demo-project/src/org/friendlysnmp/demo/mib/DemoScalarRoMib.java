 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoScalarRoMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoScalarRoMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoScalarRoMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1 });

  // Identities
  // Scalars
  public static final OID oidUserDir = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1,1,1,0 });
  public static final OID oidTicksCount = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1,1,2,0 });
  public static final OID oidUserName = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1,1,3,0 });
  public static final OID oidUserLevel = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1,1,4,0 });
  public static final OID oidUserAge = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,1,1,5,0 });
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_DEMO_SCALAR_RO_MIB = "DEMO-SCALAR-RO-MIB";
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DEMOAGEINTTC = "DemoAgeIntTC";
  private static final String TC_DEMOUSERLEVELTC = "DemoUserLevelTC";
  private static final String TC_DISPLAYSTRING = "DisplayString";

  // Scalars
  private MOScalar<OctetString> userDir;
  private MOScalar<Integer32> ticksCount;
  private MOScalar<OctetString> userName;
  private MOScalar<Integer32> userLevel;
  private MOScalar<Integer32> userAge;

  // Tables


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoScalarRoMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoScalarRoMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoScalarRoMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoScalarRoMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    userDir = 
      moFactory.createScalar(oidUserDir,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY), 
                             null,
                             TC_MODULE_SNMPV2_TC, TC_DISPLAYSTRING);
    ticksCount = 
      moFactory.createScalar(oidTicksCount,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY), 
                             new Integer32());
    userName = 
      moFactory.createScalar(oidUserName,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY), 
                             null,
                             TC_MODULE_SNMPV2_TC, TC_DISPLAYSTRING);
    userLevel = 
      moFactory.createScalar(oidUserLevel,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY), 
                             null,
                             TC_MODULE_DEMO_SCALAR_RO_MIB, TC_DEMOUSERLEVELTC);
    userAge = 
      moFactory.createScalar(oidUserAge,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY), 
                             null,
                             TC_MODULE_DEMO_SCALAR_RO_MIB, TC_DEMOAGEINTTC);
  }

  public MOScalar<OctetString> getUserDir() {
    return userDir;
  }
  public MOScalar<Integer32> getTicksCount() {
    return ticksCount;
  }
  public MOScalar<OctetString> getUserName() {
    return userName;
  }
  public MOScalar<Integer32> getUserLevel() {
    return userLevel;
  }
  public MOScalar<Integer32> getUserAge() {
    return userAge;
  }




  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.userDir, context);
    server.register(this.ticksCount, context);
    server.register(this.userName, context);
    server.register(this.userLevel, context);
    server.register(this.userAge, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.userDir, context);
    server.unregister(this.ticksCount, context);
    server.unregister(this.userName, context);
    server.unregister(this.userLevel, context);
    server.unregister(this.userAge, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars

  // Value Validators


  // Rows and Factories


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoScalarRoMib
  protected void addTCsToFactory(MOFactory moFactory) {
   moFactory.addTextualConvention(new DemoAgeIntTC()); 
   moFactory.addTextualConvention(new DemoUserLevelTC()); 
  }


  public class DemoAgeIntTC implements TextualConvention {
  	
    public DemoAgeIntTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_SCALAR_RO_MIB;
    }
  	
    public String getName() {
      return TC_DEMOAGEINTTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
      	((AssignableFromLong)v).setValue(0L);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoAgeIntTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new ConstraintsImpl();
      ((ConstraintsImpl)vc).add(new Constraint(0L, 100L));
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoAgeIntTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new ConstraintsImpl();
        ((ConstraintsImpl)vc).add(new Constraint(0L, 100L));
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoAgeIntTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


  public class DemoUserLevelTC implements TextualConvention {
    public static final int beginner = 1;
    public static final int intermediate = 4;
    public static final int experienced = 8;
    public static final int guru = 12;
  	
    public DemoUserLevelTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_SCALAR_RO_MIB;
    }
  	
    public String getName() {
      return TC_DEMOUSERLEVELTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
        ((AssignableFromLong)v).setValue(1);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoUserLevelTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new EnumerationConstraint(
        new int[] { beginner,
                    intermediate,
                    experienced,
                    guru });
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoUserLevelTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new EnumerationConstraint(
          new int[] { beginner,
                      intermediate,
                      experienced,
                      guru });
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoUserLevelTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


