/*
 * File: Pane04TableDynamic.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

@SuppressWarnings("serial")
public class Pane04TableDynamic extends PaneTableBase {

    public Pane04TableDynamic() {
        super(new TableModelFlight());
    } // Pane04TableDynamic()
    
    @Override
    protected String getNotes() {
        return 
        " - Table read-write-create GET / SET requests demo. Use DEMO-TABLE-FLIGHT-MIB " +
        "to access the table in the MIB browser. " +
        "\n" +
        " - This table is implemented with all data stored in the application " +
        "with GET / SET / VALIDATE listeners." +
        "\n" +
        " - Usually this type of table should be modified from the MIB browser. " +
        "This application provides an option to modify it as well." +
        "\n" +
        " - The table is saved into persistent storage if it is modified from " +
        "the MIB browser. The table persists after application restart." +
        "\n" +
        " - The valid departure time has the form HH:MM where HH=00..23, MM=00..59";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Dynamic table (flights)";
    } // getTitle()
    
} // class Pane04TableDynamic
