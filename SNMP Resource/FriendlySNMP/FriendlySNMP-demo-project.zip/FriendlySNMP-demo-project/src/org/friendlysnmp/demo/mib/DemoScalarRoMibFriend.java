/*
 * File: DemoScalarRoMibFriend.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo.mib;

import org.friendlysnmp.AgentWorker;
import org.friendlysnmp.FException;
import org.friendlysnmp.FScalar;
import org.friendlysnmp.mib.BaseMib;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOServer;
import org.snmp4j.agent.mo.DefaultMOFactory;
import org.snmp4j.smi.OctetString;

public class DemoScalarRoMibFriend extends BaseMib {

    private DemoScalarRoMib mibORIG;

    // Scalars
    private FScalar ticksCount;
    private FScalar userAge;
    private FScalar userDir;
    private FScalar userLevel;
    private FScalar userName;

    public DemoScalarRoMibFriend() {
        super();
    } // DemoScalarRoMibFriend()

    @Override
    public void init(AgentWorker agent) throws FException {
        super.init(agent);
        mibORIG = new DemoScalarRoMib(DefaultMOFactory.getInstance());
        // Scalars
        ticksCount = new FScalar("ticksCount", mibORIG.getTicksCount(), agent);
        addNode(ticksCount);
        userAge = new FScalar("userAge", mibORIG.getUserAge(), agent);
        addNode(userAge);
        userDir = new FScalar("userDir", mibORIG.getUserDir(), agent);
        addNode(userDir);
        userLevel = new FScalar("userLevel", mibORIG.getUserLevel(), agent);
        addNode(userLevel);
        userName = new FScalar("userName", mibORIG.getUserName(), agent);
        addNode(userName);
    } // init()

    @Override
    public void registerMOs(MOServer server, OctetString context)
    throws DuplicateRegistrationException
    {
        mibORIG.registerMOs(server, context);
    } // registerMOs()

    @Override
    public void unregisterMOs(MOServer server, OctetString context) {
        mibORIG.unregisterMOs(server, context);
    } // unregisterMOs()

    public FScalar getTicksCount() {
        return ticksCount;
    } // getTicksCount()

    public FScalar getUserAge() {
        return userAge;
    } // getUserAge()

    public FScalar getUserDir() {
        return userDir;
    } // getUserDir()

    public FScalar getUserLevel() {
        return userLevel;
    } // getUserLevel()

    public FScalar getUserName() {
        return userName;
    } // getUserName()

} // class DemoScalarRoMibFriend
