 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoTableMarriageMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoTableMarriageMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoTableMarriageMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,6 });

  // Identities
  // Scalars
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_DEMO_TABLE_MARRIAGE_MIB = "DEMO-TABLE-MARRIAGE-MIB";
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DEMOMARRIGEYEARTC = "DemoMarrigeYearTC";
  private static final String TC_DISPLAYSTRING = "DisplayString";
  private static final String TC_ROWSTATUS = "RowStatus";

  // Scalars

  // Tables
  public static final OID oidMarriageEntry = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,6,1,9,1 });

  // Index OID definitions
  public static final OID oidMarriageHusbandName =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,6,1,9,1,2 });
  public static final OID oidMarriageWifeName =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,6,1,9,1,3 });

  // Column TC definitions for marriageEntry:
  public static final String tcModuleDemoTableMarriageMib = "DEMO-TABLE-MARRIAGE-MIB";
  public static final String tcDefDemoMarrigeYearTC = "DemoMarrigeYearTC";
  public static final String tcModuleSNMPv2Tc = "SNMPv2-TC";
  public static final String tcDefDisplayString = "DisplayString";
  public static final String tcDefRowStatus = "RowStatus";
    
  // Column sub-identifier definitions for marriageEntry:
  public static final int colMarriageYear = 4;
  public static final int colMarriageCity = 5;
  public static final int colMarriageRowStatus = 10;

  // Column index definitions for marriageEntry:
  public static final int idxMarriageYear = 0;
  public static final int idxMarriageCity = 1;
  public static final int idxMarriageRowStatus = 2;

  private MOTableSubIndex[] marriageEntryIndexes;
  private MOTableIndex marriageEntryIndex;
  
  private MOTable<MarriageEntryRow,
                  MOColumn,
                  MOTableModel<MarriageEntryRow>> marriageEntry;
  private MOTableModel<MarriageEntryRow> marriageEntryModel;


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoTableMarriageMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoTableMarriageMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoTableMarriageMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoTableMarriageMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    createMarriageEntry(moFactory);
  }



  public MOTable<MarriageEntryRow,MOColumn,MOTableModel<MarriageEntryRow>> getMarriageEntry() {
    return marriageEntry;
  }


  @SuppressWarnings(value={"unchecked"})
  private void createMarriageEntry(MOFactory moFactory) {
    // Index definition
    marriageEntryIndexes = 
      new MOTableSubIndex[] {
      moFactory.createSubIndex(oidMarriageHusbandName, 
                               SMIConstants.SYNTAX_OCTET_STRING, 1, 16)
,
      moFactory.createSubIndex(oidMarriageWifeName, 
                               SMIConstants.SYNTAX_OCTET_STRING, 1, 16)
    };

    marriageEntryIndex = 
      moFactory.createIndex(marriageEntryIndexes,
                            false,
                            new MOTableIndexValidator() {
      public boolean isValidIndex(OID index) {
        boolean isValidIndex = true;
     //--AgentGen BEGIN=marriageEntry::isValidIndex
     //--AgentGen END
        return isValidIndex;
      }
    });

    // Columns
    MOColumn[] marriageEntryColumns = new MOColumn[3];
    marriageEntryColumns[idxMarriageYear] = 
      new MOMutableColumn<Integer32>(colMarriageYear,
                          SMIConstants.SYNTAX_INTEGER32,
                          moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                          (Integer32)null);
    ValueConstraint marriageYearVC = new ConstraintsImpl();
    ((ConstraintsImpl)marriageYearVC).add(new Constraint(0L, 3000L));
    ((MOMutableColumn)marriageEntryColumns[idxMarriageYear]).
      addMOValueValidationListener(new ValueConstraintValidator(marriageYearVC));                                  
    ((MOMutableColumn)marriageEntryColumns[idxMarriageYear]).
      addMOValueValidationListener(new MarriageYearValidator());
    marriageEntryColumns[idxMarriageCity] = 
      new DisplayString(colMarriageCity,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint marriageCityVC = new ConstraintsImpl();
    ((ConstraintsImpl)marriageCityVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)marriageEntryColumns[idxMarriageCity]).
      addMOValueValidationListener(new ValueConstraintValidator(marriageCityVC));                                  
    ((MOMutableColumn)marriageEntryColumns[idxMarriageCity]).
      addMOValueValidationListener(new MarriageCityValidator());
    marriageEntryColumns[idxMarriageRowStatus] = 
      new RowStatus(colMarriageRowStatus);
    ValueConstraint marriageRowStatusVC = new EnumerationConstraint(
      new int[] { 1,
                  2,
                  3,
                  4,
                  5,
                  6 });
    ((MOMutableColumn)marriageEntryColumns[idxMarriageRowStatus]).
      addMOValueValidationListener(new ValueConstraintValidator(marriageRowStatusVC));                                  
    ((MOMutableColumn)marriageEntryColumns[idxMarriageRowStatus]).
      addMOValueValidationListener(new MarriageRowStatusValidator());
    // Table model
    marriageEntryModel = (MOTableModel<MarriageEntryRow>)
      moFactory.createTableModel(oidMarriageEntry,
                                 marriageEntryIndex,
                                 marriageEntryColumns);
    ((MOMutableTableModel<MarriageEntryRow>)marriageEntryModel).setRowFactory(
      new MarriageEntryRowFactory());
    marriageEntry = 
      moFactory.createTable(oidMarriageEntry,
                            marriageEntryIndex,
                            marriageEntryColumns,
                            marriageEntryModel);
  }



  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.marriageEntry, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.marriageEntry, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars

  // Value Validators

  /**
   * The <code>MarriageYearValidator</code> implements the value
   * validation for <code>MarriageYear</code>.
   */
  static class MarriageYearValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      long v = ((Integer32)newValue).getValue();
      if (!(((v >= 0L) && (v <= 3000L)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_VALUE);
        return;
      }
     //--AgentGen BEGIN=marriageYear::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>MarriageCityValidator</code> implements the value
   * validation for <code>MarriageCity</code>.
   */
  static class MarriageCityValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=marriageCity::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>MarriageRowStatusValidator</code> implements the value
   * validation for <code>MarriageRowStatus</code>.
   */
  static class MarriageRowStatusValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
     //--AgentGen BEGIN=marriageRowStatus::validate
     //--AgentGen END
    }
  }

  // Rows and Factories

  public class MarriageEntryRow extends DefaultMOMutableRow2PC {

     //--AgentGen BEGIN=marriageEntry::RowMembers
     //--AgentGen END

    public MarriageEntryRow(OID index, Variable[] values) {
      super(index, values);
     //--AgentGen BEGIN=marriageEntry::RowConstructor
     //--AgentGen END
    }
    
    public Integer32 getMarriageYear() {
     //--AgentGen BEGIN=marriageEntry::getMarriageYear
     //--AgentGen END
      return (Integer32) super.getValue(idxMarriageYear);
    }  
    
    public void setMarriageYear(Integer32 newValue) {
     //--AgentGen BEGIN=marriageEntry::setMarriageYear
     //--AgentGen END
      super.setValue(idxMarriageYear, newValue);
    }
    
    public OctetString getMarriageCity() {
     //--AgentGen BEGIN=marriageEntry::getMarriageCity
     //--AgentGen END
      return (OctetString) super.getValue(idxMarriageCity);
    }  
    
    public void setMarriageCity(OctetString newValue) {
     //--AgentGen BEGIN=marriageEntry::setMarriageCity
     //--AgentGen END
      super.setValue(idxMarriageCity, newValue);
    }
    
    public Integer32 getMarriageRowStatus() {
     //--AgentGen BEGIN=marriageEntry::getMarriageRowStatus
     //--AgentGen END
      return (Integer32) super.getValue(idxMarriageRowStatus);
    }  
    
    public void setMarriageRowStatus(Integer32 newValue) {
     //--AgentGen BEGIN=marriageEntry::setMarriageRowStatus
     //--AgentGen END
      super.setValue(idxMarriageRowStatus, newValue);
    }
    
    public Variable getValue(int column) {
     //--AgentGen BEGIN=marriageEntry::RowGetValue
     //--AgentGen END
      switch(column) {
        case idxMarriageYear: 
        	return getMarriageYear();
        case idxMarriageCity: 
        	return getMarriageCity();
        case idxMarriageRowStatus: 
        	return getMarriageRowStatus();
        default:
          return super.getValue(column);
      }
    }
    
    public void setValue(int column, Variable value) {
     //--AgentGen BEGIN=marriageEntry::RowSetValue
     //--AgentGen END
      switch(column) {
        case idxMarriageYear: 
        	setMarriageYear((Integer32)value);
        	break;
        case idxMarriageCity: 
        	setMarriageCity((OctetString)value);
        	break;
        case idxMarriageRowStatus: 
        	setMarriageRowStatus((Integer32)value);
        	break;
        default:
          super.setValue(column, value);
      }
    }

     //--AgentGen BEGIN=marriageEntry::Row
     //--AgentGen END
  }
  
  class MarriageEntryRowFactory 
        implements MOTableRowFactory<MarriageEntryRow>
  {
    public synchronized MarriageEntryRow createRow(OID index, Variable[] values)
        throws UnsupportedOperationException 
    {
      MarriageEntryRow row = 
        new MarriageEntryRow(index, values);
     //--AgentGen BEGIN=marriageEntry::createRow
     //--AgentGen END
      return row;
    }
    
    public synchronized void freeRow(MarriageEntryRow row) {
     //--AgentGen BEGIN=marriageEntry::freeRow
     //--AgentGen END
    }

     //--AgentGen BEGIN=marriageEntry::RowFactory
     //--AgentGen END
  }


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoTableMarriageMib
  protected void addTCsToFactory(MOFactory moFactory) {
   moFactory.addTextualConvention(new DemoMarrigeYearTC()); 
  }


  public class DemoMarrigeYearTC implements TextualConvention {
  	
    public DemoMarrigeYearTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_TABLE_MARRIAGE_MIB;
    }
  	
    public String getName() {
      return TC_DEMOMARRIGEYEARTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
      	((AssignableFromLong)v).setValue(0L);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoMarrigeYearTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new ConstraintsImpl();
      ((ConstraintsImpl)vc).add(new Constraint(0L, 3000L));
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoMarrigeYearTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new ConstraintsImpl();
        ((ConstraintsImpl)vc).add(new Constraint(0L, 3000L));
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoMarrigeYearTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


