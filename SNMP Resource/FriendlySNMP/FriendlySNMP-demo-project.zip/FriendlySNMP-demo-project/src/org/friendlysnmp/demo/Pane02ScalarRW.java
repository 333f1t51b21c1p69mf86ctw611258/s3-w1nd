/*
 * File: Pane02ScalarRW.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.friendlysnmp.FException;
import org.friendlysnmp.FScalar;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.ValueValidation;
import org.friendlysnmp.demo.mib.DemoScalarRwMibFriend;
import org.friendlysnmp.demo.mib.DemoScalarRwMib.DemoImageFormatTC;
import org.friendlysnmp.event.FRestoreDefaultEvent;
import org.friendlysnmp.event.FScalarGetListener;
import org.friendlysnmp.event.FRestoreDefaultListener;
import org.friendlysnmp.event.FScalarSetListener;
import org.friendlysnmp.event.FScalarValidationListener;

@SuppressWarnings("serial")
public class Pane02ScalarRW extends PaneBase {

    private final static String IMAGE_FILENAME = "Beach"; 
    private final static int    IMAGE_FORMAT   = ImageFormat.JPG.format; 
    private final static String IMAGE_SIZE     = "800x600"; 
    
    private JTextField tfImageFileName;
    private JComboBox<ImageFormat> cbImageFormat;
    private JTextField tfImageSize;
    private DemoScalarRwMibFriend mib;
    
    private enum ImageFormat {
        //bmp(2), jpg(3), gif(5), png(12) 
        BMP(DemoImageFormatTC.bmp), 
        JPG(DemoImageFormatTC.jpg), 
        GIF(DemoImageFormatTC.gif), 
        PNG(DemoImageFormatTC.png);
        
        int format;
        ImageFormat(int format) {
            this.format = format;
        }
        public String toString() {
            return super.toString().toLowerCase();
        }
        
        static ImageFormat getImageFormat(int format) {
            ImageFormat[] values = ImageFormat.values();
            for (ImageFormat fmt : values) {
                if (fmt.format == format) {
                   return fmt; 
                }
            }
            return null;
        }
    } // enum ImageFormat
    
    @Override
    protected void initSNMP(FriendlyAgent agent) throws FException {
        mib = new DemoScalarRwMibFriend();
        agent.addMIB(mib);
        
        // Image File Name
        FScalar scalarImageFilename = mib.getImageFilename(); 
        scalarImageFilename.setVolatile(false); // loads persistent value (if exist)
        if (!scalarImageFilename.isPersistLoaded()) {
            scalarImageFilename.setValue(IMAGE_FILENAME);
        }
        scalarImageFilename.addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                scalar.setValueEx(tfImageFileName.getText());
            }
        });
        scalarImageFilename.addSetListener(new FScalarSetListener() {
            @Override
            public void set(FScalar scalar) {
                tfImageFileName.setText(scalar.getValue().toString());
            }
        });  
        scalarImageFilename.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev) throws FException {
                FScalar scalar = ev.getScalar();
                scalar.setValue(IMAGE_FILENAME);
                tfImageFileName.setText(scalar.getValue().toString());
            }
        });
        
        // Image Format
        FScalar scalarImageFormat = mib.getImageFormat();
        scalarImageFormat.setVolatile(false); // loads persistent value (if exist)
        if (!scalarImageFormat.isPersistLoaded()) {
            scalarImageFormat.setValue(IMAGE_FORMAT);
        }
        scalarImageFormat.addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                Object objSel = cbImageFormat.getSelectedItem();
                int format = ((ImageFormat)objSel).format;
                scalar.setValueEx(format);
            }
        });
        scalarImageFormat.addSetListener(new FScalarSetListener() {
            @Override
            public void set(FScalar scalar) {
                // Default value is already set while GUI initialization
                Object objFormat = scalar.getValue();
                int format = ((Integer)objFormat).intValue();
                cbImageFormat.setSelectedItem(ImageFormat.getImageFormat(format));
            }
        });  
        scalarImageFormat.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev) throws FException {
                FScalar scalar = ev.getScalar();
                scalar.setValue(IMAGE_FORMAT);
                cbImageFormat.setSelectedItem(ImageFormat.getImageFormat(IMAGE_FORMAT));
            }
        });
        
        // Image Size
        FScalar scalarImageSize = mib.getImageSize();
        scalarImageSize.setVolatile(false); // loads persistent value (if exist)
        if (!scalarImageSize.isPersistLoaded()) {
            scalarImageSize.setValue(IMAGE_SIZE);
        }
        scalarImageSize.addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                try {
                    scalar.setValue(tfImageSize.getText());
                } catch (FException e) {
                    ErrorPresenter.showError(e, 
                            "Failure to set value to %s", scalar.getFIDtoString());
                }
            }
        });
        scalarImageSize.addSetListener(new FScalarSetListener() {
            @Override
            public void set(FScalar scalar) {
                tfImageSize.setText(scalar.getValue().toString());
            }
        });  
        scalarImageSize.addValidationListener(new FScalarValidationListener() {
            @Override
            public ValueValidation validate(FScalar scalar, Object objValue) {
                String value = objValue.toString(); // Expected "NNNxMMM"
                String[] dim = value.split("x");
                if (dim.length != 2) {
                    return ValueValidation.WRONG_VALUE;
                }
                for (String s : dim) {
                    try {
                        int size = Integer.parseInt(s);
                        if (size == 0) {
                            return ValueValidation.WRONG_VALUE;
                        }
                    } catch (NumberFormatException e) {
                        return ValueValidation.WRONG_VALUE;
                    }
                }
                return ValueValidation.SUCCESS;
            }
        });  
        scalarImageSize.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev) throws FException {
                FScalar scalar = ev.getScalar();
                scalar.setValue(IMAGE_SIZE);
                tfImageSize.setText(scalar.getValue().toString());
            }
        });
    } // initSNMP()

    @Override
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        // Section "Image File name"
        tfImageFileName = addTextField(panel, "Image file name");
        String imageFileName = mib.getImageFilename().getValue().toString();
        tfImageFileName.setText(imageFileName);
        
        // Section "Image Format"
        cbImageFormat = addComboBox(panel, "Image format");
        cbImageFormat.addItem(ImageFormat.BMP);
        cbImageFormat.addItem(ImageFormat.JPG);
        cbImageFormat.addItem(ImageFormat.GIF);
        cbImageFormat.addItem(ImageFormat.PNG);
        Object objFormat = mib.getImageFormat().getValue();
        int format = ((Integer)objFormat).intValue();
        cbImageFormat.setSelectedItem(ImageFormat.getImageFormat(format));
        
        // Section "File name"
        tfImageSize = addTextField(panel, "Image size");
        tfImageSize.setEditable(false);
        tfImageSize.setBackground(new Color(255,255,230));
        String imageSize = mib.getImageSize().getValue().toString();
        tfImageSize.setText(imageSize);

        addBottomFiller(panel);
        return panel;
    } // getContentPanel()
    
    @Override
    protected String getNotes() {
        return 
        " - Scalar read-write GET / SET requests demo. Use DEMO-SCALAR-RW-MIB " +
        "to access scalars in the MIB browser. " +
        "\n" +
        " - Check the demo code " +
        "on how to use GET / SET / VALIDATE / RESTORE DEFAULT listeners." +
        "\n" +
        " - The valid format for the image size is NNNxMMM. Try setting not " +
        "valid image size from the MIB browser and check how it is rejected " +
        "by the application." +
        "\n" +
        " - Set any values from the MIB browser and restart application " +
        "to check how these values persist.";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Scalar read-write";
    } // getTitle()
    
} // class Pane02ScalarRW
