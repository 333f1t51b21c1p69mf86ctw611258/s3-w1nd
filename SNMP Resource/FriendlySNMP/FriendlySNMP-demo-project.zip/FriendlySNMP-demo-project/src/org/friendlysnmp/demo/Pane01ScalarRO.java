/*
 * File: Pane01ScalarRO.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.friendlysnmp.FException;
import org.friendlysnmp.FHandler;
import org.friendlysnmp.FScalar;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.demo.mib.DemoScalarRoMib.DemoUserLevelTC;
import org.friendlysnmp.demo.mib.DemoScalarRoMibFriend;
import org.friendlysnmp.event.FScalarGetListener;

@SuppressWarnings("serial")
public class Pane01ScalarRO extends PaneBase {
    //private static final Logger logger = Logger.getLogger(PaneScalarRO.class);

    private static final String USER_DIR = System.getProperty("user.dir");
    
    private JTextField tfUserDir;
    private JTextField tfTicks;
    private JTextField tfUserName;
    private JComboBox<UserLevel> cbUserLevel;
    private JTextField tfUserAge;
    private TickerThread threadTicker;
    private DemoScalarRoMibFriend mib;
    private int ticks;
    private int startCount;
    
    private enum UserLevel { 
        BEGINNER    (DemoUserLevelTC.beginner), 
        INTERMEDIATE(DemoUserLevelTC.intermediate), 
        EXPERIENCED (DemoUserLevelTC.experienced), 
        GURU        (DemoUserLevelTC.guru);
        
        int level;
        UserLevel(int level) {
            this.level = level;
        }
        public String toString() {
            return PaneBase.toCamelCase(super.toString());
        }
    } // enum UserLevel
    
    @Override
    protected void initSNMP(FriendlyAgent agent) throws FException {
        mib = new DemoScalarRoMibFriend();
        mib.addHandler(new ThisHandler());
        agent.addMIB(mib);
        
        mib.getTicksCount().addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                // Using FExceptionListener exception reporting method
                scalar.setValueEx(ticks);
            }
        });
        
        mib.getUserName().addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                // Using FExceptionListener exception reporting method
                scalar.setValueEx(tfUserName.getText());
            }
        });
        
        mib.getUserLevel().addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                Object obj = cbUserLevel.getSelectedItem();
                UserLevel userLevel = (UserLevel)obj;
                // Catching FException explicitly
                try {
                    scalar.setValue(userLevel.level);
                } catch (FException e) {
                    ErrorPresenter.showError(e, 
                            "Failure to set value to %s", 
                            mib.getUserName().getFIDtoString());
                }
            }
        });
        
        mib.getUserAge().addGetListener(new FScalarGetListener() {
            @Override
            public void get(FScalar scalar) {
                try {
                    int age = Integer.parseInt(tfUserAge.getText());
                    if (0 <= age  &&  age <= 100) {
                        mib.getUserAge().setValueEx(age);
                    }
                } catch (NumberFormatException e) {
                    mib.getUserAge().setValueEx(0);
                }
            }
        });
    } // initSNMP()

    @Override
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        // Section "User Directory"
        tfUserDir = addTextField(panel, "Default user directory");
        tfUserDir.setEditable(false);
        tfUserDir.setBackground(new Color(255,255,230));
        tfUserDir.setText(USER_DIR);
        
        // Section "Ticks"
        tfTicks = addTextField(panel, "Ticks");
        tfTicks.setEditable(false);
        tfTicks.setBackground(new Color(255,255,230));
        
        // Section "User Name"
        tfUserName = addTextField(panel, "User name");
        tfUserName.setText("Foo Bar");
        
        // Section "Status"
        cbUserLevel = addComboBox(panel, "User level");
        cbUserLevel.addItem(UserLevel.BEGINNER);
        cbUserLevel.addItem(UserLevel.INTERMEDIATE);
        cbUserLevel.addItem(UserLevel.EXPERIENCED);
        cbUserLevel.addItem(UserLevel.GURU);
        
        // Section "User Age"
        tfUserAge = addTextField(panel, "User age");
        tfUserAge.setText("25");
        
        // FException
        JButton btn = new JButton("Validate Age");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                validateAge();
            }
        });
        JPanel panelBtn = new JPanel(); 
        panelBtn.add(btn);
        panel.add(panelBtn);
        
        addBottomFiller(panel);
        
        return panel;
    } // getContentPanel()
    
    /**
     * Validation by using FExceptionListener.
     * FException is triggered if age is not valid (e.g. not numeric).
     */
    private void validateAge() {
        mib.getUserAge().setValueEx(tfUserAge.getText());
    } // validateAge()
    
    @Override
    protected String getNotes() {
        return 
        " - Scalar read-only GET requests demo. Use DEMO-SCALAR-RO-MIB " +
        "to access scalars in the MIB browser. " +
        "\n" +
        " - Check the demo code " +
        "on how to use GET listeners; how to use FHandler " +
        "class to initialize static objects and start / stop ticker thread." +
        "\n" +
        " - Enter invalid 'user age' and click button 'Validate Age' " +
        "to test agent FExceptionListener.";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Scalar read-only";
    } // getTitle()
    
    private class ThisHandler extends FHandler {
        @Override
        public void init() {
            mib.getUserDir().setValueEx(USER_DIR);
        } // init()
        
        @Override
        public void start(AgentStartType startType) {
            threadTicker = new TickerThread();
            threadTicker.start();
        } // start()

        @Override
        public void stop() {
            if (threadTicker != null) {
                threadTicker.shutdown = true;
                threadTicker.interrupt();
                threadTicker = null;
            }
        } // stop()
        
        @Override
        public void shutdown() {
            stop();
        } // shutdown()
    } // inner class ThisHandler
    
    private class TickerThread extends Thread {
        private volatile boolean shutdown;
        public void run() {
            startCount++;
            setName("TickerThread-" + startCount);
            while (!shutdown) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
                if (!shutdown) {
                    ticks++;
                    if (tfTicks != null) {
                        tfTicks.setText(Integer.toString(ticks));
                    }
                }
            }
        }
    } // inner class TickerThread     
    
} // class Pane01ScalarRO
