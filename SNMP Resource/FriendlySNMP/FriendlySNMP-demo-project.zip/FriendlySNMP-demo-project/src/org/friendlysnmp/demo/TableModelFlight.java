/*
 * File: TableModelFlight.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.table.TableColumnModel;

import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FID;
import org.friendlysnmp.FTable;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.TableRowAction;
import org.friendlysnmp.ValueValidation;
import org.friendlysnmp.demo.mib.DemoTableFlightMib;
import org.friendlysnmp.demo.mib.DemoTableFlightMibFriend;
import org.friendlysnmp.demo.mib.DemoTableFlightMib.DemoFlightStatusTC;
import org.friendlysnmp.event.FRestoreDefaultEvent;
import org.friendlysnmp.event.FRestoreDefaultListener;
import org.friendlysnmp.event.FTableGetListener;
import org.friendlysnmp.event.FTableSetListener;
import org.friendlysnmp.event.FTableValidationListener;
import org.friendlysnmp.mib.RowStatusTC;

@SuppressWarnings("serial")
public class TableModelFlight extends TableModelBase {

    private enum FlightStatus {
        BOARDING(DemoFlightStatusTC.boarding), 
        DELAYED (DemoFlightStatusTC.delayed), 
        DEPARTED(DemoFlightStatusTC.departed), 
        CANCELED(DemoFlightStatusTC.canceled);
        int status;
        FlightStatus(int status) {
            this.status = status;
        }
        public static FlightStatus find(int n) {
            FlightStatus[] a = values();
            for (FlightStatus st : a) {
                if (st.status == n) {
                    return st;
                }
            }
            return null;
        }
        public String toString() {
            return String.format("%s(%s)", super.toString().toLowerCase(), status);
        }
    } // enum FlightStatus
    
    private static class FlightRow {
        // Populate with default values
        FID id;
        String carrier = "?";
        int flightNo = 0;
        String destination = "?";
        String departTime = "00:00";
        FlightStatus statusFlight = FlightStatus.CANCELED;
        FlightRow(FID id) {
            this.id = id;
        }
    } // inner class FlightRow
    
    // Column indices
    final static public int COL_OID         = 0;
    final static public int COL_CARRIER     = 1;
    final static public int COL_FLIGHT_NO   = 2;
    final static public int COL_DESTINATION = 3;
    final static public int COL_DEPART_TIME = 4;
    final static public int COL_STATUS      = 5;
    final static private int COL_LAST       = 6;

    // Column header names
    final static private String[] HEADERS = new String[COL_LAST];
    static {
        HEADERS[COL_OID        ] = "Index";
        HEADERS[COL_CARRIER    ] = "Carrier";
        HEADERS[COL_FLIGHT_NO  ] = "Flight No";
        HEADERS[COL_DESTINATION] = "Destination";
        HEADERS[COL_DEPART_TIME] = "Depart Time";
        HEADERS[COL_STATUS     ] = "Status";
    }

    private List<FlightRow> lstRows;

    @Override
    public void updateColumnModel(TableColumnModel columnModel) {
        setColumnFixedWidth(columnModel, COL_OID, 60);
        
        JComboBox<FlightStatus> cb = new JComboBox<FlightStatus>(FlightStatus.values());
        columnModel.getColumn(COL_STATUS).setCellEditor(new DefaultCellEditor(cb));
    } // updateColumnModel()
    
    @Override
    public void initSNMP(FriendlyAgent agent) throws FException {
        lstRows = new ArrayList<FlightRow>();
        loadDefaultContent();
        
        DemoTableFlightMibFriend mib = new DemoTableFlightMibFriend();
        agent.addMIB(mib);
        
        table = mib.getFlightEntry();
        table.setVolatile(false); // loads persistent value (if exist)
        if (table.isPersistLoaded()) {
            loadTableContent(table);
        }
        FlightRow row = new FlightRow(null); // defaults
        table.setDefaultValues(row.carrier, row.flightNo, 
                row.destination, row.departTime, FlightStatus.CANCELED.status);
        table.addGetListener(new FTableGetListener() {
            @Override
            public void get(FTable table) {
                loadFlightTable();
            }
        });
        table.addValidationListener(new FTableValidationListener() {
            @Override
            public ValueValidation validate( 
                    FTable table, Object objNewValue, 
                    FID idRow, FColumn col, TableRowAction action) 
            {
                if (col.equals(DemoTableFlightMibFriend.COLUMN_FlightDepartTime)) {
                    return validateDepartTime(objNewValue);
                }
                return ValueValidation.SUCCESS;
            }
        });
        table.addSetListener(new FTableSetListener() {
            @Override
            public void set(FTable table, FID idRow, FColumn col, TableRowAction action) {
                updateFlightTable(idRow, col, action);
            }
        });
        table.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev) {
                loadDefaultContent();                
                fireTableDataChanged();
            }
        });
    } // initSNMP()

    private void loadTableContent(FTable table) {
        lstRows.clear();
        try {
            for (int r = 0;  r < table.getRowCount();  r++) {
                FID idRow = table.getRowID(r);
                String carrier = table.getValueAt(idRow, 
                        DemoTableFlightMibFriend.COLUMN_FlightCarrier).toString();
                int flightNo = (Integer)table.getValueAt(idRow, 
                        DemoTableFlightMibFriend.COLUMN_FlightNumber);
                String destination = table.getValueAt(idRow, 
                        DemoTableFlightMibFriend.COLUMN_FlightDestination).toString();
                String departTime = table.getValueAt(idRow, 
                        DemoTableFlightMibFriend.COLUMN_FlightDepartTime).toString();
                int status = (Integer)table.getValueAt(idRow, 
                        DemoTableFlightMibFriend.COLUMN_FlightStatus);
                loadRow(idRow.getInt()[0], 
                        carrier,  flightNo, destination, departTime, FlightStatus.find(status));
            }
        } catch (FException e) {
        }
        sortRows();        
    }    
    
    private void loadDefaultContent() {
        lstRows.clear();
        loadRow(3, "Delta",  25, "Chicago", "13:22", FlightStatus.BOARDING);
        loadRow(7, "United", 12, "Paris",   "02:15", FlightStatus.DELAYED);
        loadRow(8, "TED",    75, "Boston",  "22:03", FlightStatus.DEPARTED);
        loadRow(9, "JetBlue",233,"Seatle",  "09:48", FlightStatus.CANCELED);
        sortRows();        
    }
    
    private void loadRow(int id,
            String carrier, int flightNo, String destination, 
            String departTime, FlightStatus statusFlight) 
    {
        FlightRow row = new FlightRow(new FID(id));
        row.carrier = carrier;
        row.flightNo = flightNo;
        row.destination = destination;
        row.departTime = departTime;
        row.statusFlight = statusFlight;
        lstRows.add(row);
    } // loadRow()    
    
    public int getColumnCount() {
        // Implements AbstractTableModel
        return HEADERS.length;
    }

    @Override
    public Class<?> getColumnClass(int c) {
        return getValueAt(0, c).getClass(); // to render and edit Integer
    }
    
    @Override
    public String getColumnName(int c) {
        return HEADERS[c];
    }
    
    public int getRowCount() {
        // Implements AbstractTableModel
        return lstRows.size();
    }

    @Override
    public boolean isCellEditable(int indexRow, int indexCol) {
        switch (indexCol) {
            case COL_OID:
                return false;
            case COL_CARRIER: 
            case COL_FLIGHT_NO:
            case COL_DESTINATION:
            case COL_DEPART_TIME:
            case COL_STATUS:
                return true;
            default: 
                throw new IllegalArgumentException("Not valid column: " + indexCol);
        }
    } // isCellEditable()
    
    public Object getValueAt(int r, int c) {
        // Implements AbstractTableModel
        FlightRow row = lstRows.get(r);
        switch (c) {
            case COL_OID:
                return row.id.getOID();
            case COL_CARRIER: 
                return row.carrier;
            case COL_FLIGHT_NO:
                return row.flightNo;
            case COL_DESTINATION:
                return row.destination;
            case COL_DEPART_TIME:
                return row.departTime;
            case COL_STATUS:
                return row.statusFlight;
            default: 
                throw new IllegalArgumentException("Not valid column: " + c);
        }
    } // getValueAt()

    @Override
    public void setValueAt(Object val, int r, int c) {
        if (r < 0  ||  r >= lstRows.size()) {
            // This exception may happen when a new row is created
            // with createAndGo status and cell values in the row are set 
            // in a single commit action from MibExplorer.
            // MibExplorer sends SET requests in columns order and request  
            // to create a row is sent _after_ SET requests for other cells.
            // This exception is for setting cell value before row is created.
            throw new IllegalArgumentException(String.format(
                    "Not valid row %d column %d value '%s'", r, c, val));
        }
        FlightRow row = lstRows.get(r);
        switch (c) {
            case COL_CARRIER: 
                row.carrier = (String)val;
                break;
            case COL_FLIGHT_NO:
                if (val == null) {
                    val = Integer.valueOf(0);
                }
                row.flightNo = (Integer)val;
                row.flightNo = Math.abs(row.flightNo);
                while (row.flightNo > 999) {
                    row.flightNo /= 10;
                }
                break;
            case COL_DESTINATION:
                row.destination = (String)val;
                break;
            case COL_DEPART_TIME:
                if (validateDepartTime(val) == ValueValidation.SUCCESS) {
                    row.departTime = (String)val;
                }
                break;
            case COL_STATUS:
                if (val instanceof FlightStatus) {
                    // Call from JTable: ComboBox selected item
                    row.statusFlight = (FlightStatus)val;
                }
                if (val instanceof Integer) {
                    // Call from MIB Browser
                    row.statusFlight = FlightStatus.find((Integer)val);
                }
                break;
            default: 
                throw new IllegalArgumentException(String.format(
                        "Not valid column: %s", c));
        }
    } // setValueAt()
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int addRow() {
        // Call from UI
        int index = -1;
        for (FlightRow row : lstRows) {
            index = Math.max(index, row.id.getInt()[0]);
        }
        FID id = new FID(index + 1);
        lstRows.add(new FlightRow(id));
        return lstRows.size() - 1;
    } // addRow()

    @Override
    public int deleteRow(int indexRow) {
        // Call from UI
        lstRows.remove(indexRow);
        if (indexRow >= lstRows.size()) {
            indexRow--;
        }
        return indexRow;
    } // deleteRow()

    private void loadFlightTable() {
        // Call from agent on GET action in MIB browser.
        try {
            table.deleteAll();
            for (FlightRow row : lstRows) {
                FID idRow = table.addRow(row.id);
                table.setValueAt(row.carrier,    
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightCarrier);
                table.setValueAt(row.flightNo,   
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightNumber);
                table.setValueAt(row.destination,
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightDestination);
                table.setValueAt(row.departTime, 
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightDepartTime);
                table.setValueAt(row.statusFlight.status, 
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightStatus);
                table.setValueAt(RowStatusTC.active, 
                        idRow, DemoTableFlightMibFriend.COLUMN_FlightRowStatus);
            }
        } catch (FException e) {
            ErrorPresenter.showError(e, 
                    "Failure to update table %s", table.getFIDtoString());
        }
    } // loadFlightTable()
    
    private ValueValidation validateDepartTime(Object objNewValue) 
    {
        // Call from agent on SET action in MIB browser.
        // Depart time should be in form: HH:MM where HH=00..23, MM=00..59  
        final Pattern paternHHcMM = Pattern.compile("([0-1]\\d|2[0-3]):[0-5]\\d");
        //                                              00-19 | 20-23 : 00-59
        if (objNewValue instanceof String) {
            Matcher m = paternHHcMM.matcher((String)objNewValue);
            return m.matches() ? ValueValidation.SUCCESS : ValueValidation.WRONG_VALUE;
        }
        return ValueValidation.WRONG_TYPE;
    } // validateDepartTime()
    
    private void updateFlightTable(FID idRow, FColumn col, TableRowAction action) {
        // Call from agent on SET action in MIB browser.
        // NOTE. Row index in table does not match indexRow in lstRows:
        //   - table object does not have this row after DELETE action.
        //   - table object already has a new row for CREATE action.
        int indexRow = getRowIndex(idRow);
        try {
            switch (action) {
                case ROW_CHANGE:
                    Object obj = table.getValueAt(idRow, col);
                    setValueAt(obj, indexRow, convertMibToColumn(col));
                    break;
                case ROW_CREATE:
                    lstRows.add(new FlightRow(idRow));
                    sortRows();        
                    break;
                case ROW_DELETE:
                    lstRows.remove(indexRow);
                    break;
                default: 
                    throw new IllegalArgumentException("Not valid action: " + action);
            }
            fireTableDataChanged();
        } catch (FException e) {
            ErrorPresenter.showError(e, 
                    "Failure to set value for cell for Row ID %s, Column %s", 
                    idRow, col);
        }
    } // updateFlightTable()
    
    private int convertMibToColumn(FColumn col) {
        switch (col.getIndex_InTable()) {
            case DemoTableFlightMib.idxFlightCarrier:    return COL_CARRIER; 
            case DemoTableFlightMib.idxFlightNumber:     return COL_FLIGHT_NO;
            case DemoTableFlightMib.idxFlightDestination:return COL_DESTINATION;
            case DemoTableFlightMib.idxFlightDepartTime: return COL_DEPART_TIME;
            case DemoTableFlightMib.idxFlightStatus:     return COL_STATUS;
            default: 
                throw new IllegalArgumentException("Not valid column: " + col);
        }
    } // convertColumnToMib()

    private int getRowIndex(FID idRow) {
        for (int i = 0;  i < lstRows.size();  i++) {
            FlightRow row = lstRows.get(i);
            if (row.id.equals(idRow)) {
                return i;
            }
        }
        return -1;
    } // getRowIndex()
    
    private void sortRows() {
        class FlightRowComparator<T> implements Comparator<T> {
            public int compare(T o1, T o2) {
                FlightRow row1 = (FlightRow)o1;
                FlightRow row2 = (FlightRow)o2;
                return row1.id.compareTo(row2.id);
            }
        } // inner class FlightRowComparator
        final FlightRowComparator<FlightRow> comp = 
            new FlightRowComparator<FlightRow>();  
        Collections.sort(lstRows, comp);
    } // sortRows()
    
} // class TableModelFlight
