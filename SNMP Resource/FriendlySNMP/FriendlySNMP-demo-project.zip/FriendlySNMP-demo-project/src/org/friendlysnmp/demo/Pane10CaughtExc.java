/*
 * File: Pane10CaughtExc.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.SocketException;
import java.security.cert.CertificateException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.ThrowableFormatter;

@SuppressWarnings("serial")
public class Pane10CaughtExc extends PaneBase {

    private JTextArea taConsole;
    private JButton btnClear;
    private JButton btnCreate;
    private JButton btnComment;
    private JButton btnReport;
    
    private String comment;
    private Exception eRoot;
    private Exception eLast;
    private FriendlyAgent agent;
    
    @Override
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        
        // Root exception with cause exceptions
        taConsole = new JTextArea();
        taConsole.setEditable(false);
        taConsole.setBackground(new Color(255,255,230));
        taConsole.setFont(FONT_CONSOLE);
        JScrollPane paneScroll = new JScrollPane(taConsole, 
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
        panel.add(paneScroll, BorderLayout.CENTER);
        
        // Buttons
        JPanel panelBtn = new JPanel();
        panel.add(panelBtn, BorderLayout.SOUTH);
        btnClear = new JButton("New");
        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                comment = null;
                eRoot = eLast = null;
                updateGUI();
            }
        });
        panelBtn.add(btnClear);
        
        btnCreate = new JButton();
        btnCreate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addException();
                updateGUI();
            }
        });
        panelBtn.add(btnCreate);
        
        btnComment = new JButton("Set Comment");
        btnComment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setComment();
                updateGUI();
            }
        });
        panelBtn.add(btnComment);
        
        btnReport = new JButton("Report Exception");
        btnReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agent.reportException(comment, eRoot);
            }
        });
        panelBtn.add(btnReport);
        updateGUI();
        
        return panel;
    } // getContentPanel()

    @Override
    protected void initSNMP(FriendlyAgent agent) {
        this.agent = agent;
    } // initSNMP()
    
    private void updateGUI() {
        btnCreate.setText(eRoot == null ? "Create Root Exception" 
                                        : "Add Cause Exception");
        String text = (eRoot == null ? "" : ThrowableFormatter.format((String)null, eRoot));
        if (comment != null) {
            text = comment + "\n" + text;
        }
        taConsole.setText(text);
        btnClear.setEnabled(eRoot != null);
        btnReport.setEnabled(eRoot != null  ||  comment != null);
    } // updateGUI()
    
    private void addException() {
        Object[] a_Option = {
                IOException.class,
                SQLException.class,
                SocketException.class,
                CertificateException.class,
                CustomException.class
        };
        // Displayed as "class java.io.IOException"
        Class<?> clazz = (Class<?>)JOptionPane.showInputDialog(
                this,
                "Choose an exception to throw:",
                "Exception creation - step 1",
                JOptionPane.PLAIN_MESSAGE,
                null,
                a_Option,
                a_Option[0]);
        if (clazz == null) {
            return;
        }
        String msg = JOptionPane.showInputDialog(
                this,
                String.format("Enter %s message:", clazz.getSimpleName()),
                "Exception creation - step 2",
                JOptionPane.PLAIN_MESSAGE);
        Exception eNew = null;
        try {
            Constructor<?> ctor = clazz.getConstructor(new Class[] { String.class });
            eNew = (Exception)ctor.newInstance((Object[])new String[] { msg });
        } catch (Exception e) {
            // InstantiationException
            // IllegalAccessException
            ErrorPresenter.showError(e, "Cannot generate exception");
            return;
        }
        if (eRoot == null) {
            eRoot = eLast = eNew;
        } else {
            eLast.initCause(eNew);
            eLast = eNew;
        }
    } // addException()
    
    private void setComment() {
        comment = JOptionPane.showInputDialog(
                this,
                "Enter comment for exception:",
                "Exception creation - comment",
                JOptionPane.PLAIN_MESSAGE);
        if (comment != null) {
            comment = comment.trim();
            if (comment.length() == 0) {
                comment = null;
            }
        }
    } // setComment()
    
    @Override
    protected String getNotes() {
        return 
        " - Reporting caught exception." +
        "\n" +
        " - Create exception and check how it is reported to the MIB browser." +
        "View exception details in the MIB browser using FRIENDLY-SNMP-MIB.";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Caught exception reporting";
    } // getTitle()
    
} // class Pane10CaughtExc
