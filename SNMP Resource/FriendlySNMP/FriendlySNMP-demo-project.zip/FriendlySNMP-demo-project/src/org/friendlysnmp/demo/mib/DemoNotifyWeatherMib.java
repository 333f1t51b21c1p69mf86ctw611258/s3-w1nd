 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings("unused")
//--AgentGen END

public class DemoNotifyWeatherMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoNotifyWeatherMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoNotifyWeatherMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,20 });

  // Identities
  // Scalars
  // Tables

  // Notifications
  public static final OID oidWeatherSunny =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,20,0,1 });   

  public static final OID oidWeatherCloudy =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,20,0,2 });   

  public static final OID oidWeatherRain =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,20,0,5 });   

  public static final OID oidWeatherSnow =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,20,0,8 });   


  // Enumerations




  // TextualConventions

  // Scalars

  // Tables


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoNotifyWeatherMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoNotifyWeatherMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoNotifyWeatherMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoNotifyWeatherMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
  }





  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications
  public void weatherSunny(NotificationOriginator notificationOriginator,
                           OctetString context, VariableBinding[] vbs) {
    notificationOriginator.notify(context, oidWeatherSunny, vbs);
  }

  public void weatherCloudy(NotificationOriginator notificationOriginator,
                            OctetString context, VariableBinding[] vbs) {
    notificationOriginator.notify(context, oidWeatherCloudy, vbs);
  }

  public void weatherRain(NotificationOriginator notificationOriginator,
                          OctetString context, VariableBinding[] vbs) {
    notificationOriginator.notify(context, oidWeatherRain, vbs);
  }

  public void weatherSnow(NotificationOriginator notificationOriginator,
                          OctetString context, VariableBinding[] vbs) {
    notificationOriginator.notify(context, oidWeatherSnow, vbs);
  }


  // Scalars

  // Value Validators


  // Rows and Factories


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoNotifyWeatherMib
  protected void addTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


