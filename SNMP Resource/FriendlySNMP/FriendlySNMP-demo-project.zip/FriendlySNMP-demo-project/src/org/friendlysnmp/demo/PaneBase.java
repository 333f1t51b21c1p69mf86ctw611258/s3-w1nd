/*
 * File: PaneBase.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.FException;

@SuppressWarnings("serial")
public abstract class PaneBase extends JPanel {

    public final static Font FONT_NOTES   = new Font(Font.DIALOG, Font.PLAIN, 12); 
    public final static Font FONT_CONSOLE = new Font(Font.MONOSPACED, Font.PLAIN, 12); 
    
    public PaneBase() {
    } // PaneBase()
    
    public void initGUI() {
        setLayout(new BorderLayout());
        JPanel panelMain = new JPanel();
        panelMain.setLayout(new BorderLayout());
        
        JPanel panelContent = getContentPanel();
        String title = getTitle();
        setTitledBorder(title, panelContent);
        panelMain.add(panelContent, BorderLayout.CENTER);
        
        String notes = getNotes();
        if (notes != null) {
            JTextArea ta = new JTextArea(notes);
            ta.setBorder(
                    BorderFactory.createCompoundBorder(
                    BorderFactory.createEtchedBorder(),         // outside 
                    BorderFactory.createEmptyBorder(5,5,5,5))); // inside
            ta.setFont(FONT_NOTES);
            ta.setBackground(panelMain.getBackground());
            ta.setLineWrap(true);
            ta.setWrapStyleWord(true);
            ta.setEditable(false);
            panelMain.add(ta, BorderLayout.SOUTH);
        }
        
        add(panelMain, BorderLayout.CENTER);
    } // initGUI()
    
    @SuppressWarnings("unused")
    protected void initSNMP(FriendlyAgent agent) throws FException {
        // Default does nothing
    } // initSNMP()
    
    protected void setTitledBorder(String title, JPanel panel) {
        if (title != null) {
            panel.setBorder(
                    BorderFactory.createCompoundBorder(
                    BorderFactory.createTitledBorder(title),   // outside 
                    BorderFactory.createEmptyBorder(5,5,5,5))); // inside
        }
    } // setTitledBorder()
    
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(155, 192, 151));
        JLabel labelMsg = new JLabel("Not implemented yet.");
        labelMsg.setFont(labelMsg.getFont().deriveFont(20.0f));
        labelMsg.setHorizontalAlignment(SwingConstants.CENTER);
        panel.setLayout(new BorderLayout());
        panel.add(labelMsg, BorderLayout.CENTER);
        return panel;
    } // getContentPanel()
    
    protected JTextField addTextField(JPanel panel, String label) {
        addLabel(panel, label);
        JTextField tf = new JTextField(); 
        panel.add(tf);
        panel.add(Box.createVerticalStrut(5));
        return tf;
    } // addTextField()
    
    protected <T> JComboBox<T> addComboBox(JPanel panel, String label) {
        addLabel(panel, label);
        JComboBox<T> cb = new JComboBox<T>(); 
        panel.add(cb);
        panel.add(Box.createVerticalStrut(5));
        return cb;
    } // addComboBox()
    
    protected void addLabel(JPanel panel, String label) {
        // JTextField as label behaves better  
        JTextField tf = new JTextField(label);
        tf.setEditable(false);
        tf.setBackground(getBackground());
        tf.setBorder(null);
        panel.add(tf);
    } // addLabel()
    
    protected void addBottomFiller(JPanel panel) {
        panel.add(new Box.Filler(new Dimension(0,0), // min 
                  new Dimension(0, 2000),            // pref - to fill the bottom
                  new Dimension(0, 2000)));          // max  
    } // addBottomFiller()
    
    protected String getNotes() {
        return "Content of this tab is under development.";
    } // getNotes()
    
    protected abstract String getTitle();

    @Override
    public String toString() {
        String prefix = "";
        try {
            String paneNN = getClass().getSimpleName().substring(4, 6); // PaneNNXxxx
            int index = Integer.parseInt(paneNN);
            if (index > 0) {
                prefix = Integer.toString(index) + ". ";
            }
        } catch (Exception e) {
        }
        return prefix + getTitle(); // to display in the left pane
    } // toString()
    
    public static final String toCamelCase(String s) {
        s = s.toLowerCase();
        char[] chars = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
    } // toCamelCase()
    
} // class PaneBase
