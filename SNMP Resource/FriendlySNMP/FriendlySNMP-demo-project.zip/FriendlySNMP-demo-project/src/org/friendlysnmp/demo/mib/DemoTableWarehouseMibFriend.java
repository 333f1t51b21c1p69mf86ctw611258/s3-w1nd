/*
 * File: DemoTableWarehouseMibFriend.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo.mib;

import org.friendlysnmp.AgentWorker;
import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FTable;
import org.friendlysnmp.mib.BaseMib;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOServer;
import org.snmp4j.agent.mo.DefaultMOFactory;
import org.snmp4j.smi.OctetString;

public class DemoTableWarehouseMibFriend extends BaseMib {

    private DemoTableWarehouseMib mibORIG;

    // Tables
    private FTable warehouseEntry;

    // Columns for table warehouseEntry
    public final static FColumn COLUMN_WarehouseItemBrand = 
        new FColumn("WarehouseItemBrand",
                DemoTableWarehouseMib.idxWarehouseItemBrand, 
                DemoTableWarehouseMib.colWarehouseItemBrand);
    public final static FColumn COLUMN_WarehouseItemName = 
        new FColumn("WarehouseItemName",
                DemoTableWarehouseMib.idxWarehouseItemName, 
                DemoTableWarehouseMib.colWarehouseItemName);
    public final static FColumn COLUMN_WarehouseItemPrice = 
        new FColumn("WarehouseItemPrice",
                DemoTableWarehouseMib.idxWarehouseItemPrice, 
                DemoTableWarehouseMib.colWarehouseItemPrice);
    public final static FColumn COLUMN_WarehouseRowStatus = 
        new FColumn("WarehouseRowStatus",
                DemoTableWarehouseMib.idxWarehouseRowStatus, 
                DemoTableWarehouseMib.colWarehouseRowStatus);

    public DemoTableWarehouseMibFriend() {
        super();
    } // DemoTableWarehouseMibFriend()

    @Override
    public void init(AgentWorker agent) throws FException {
        super.init(agent);
        mibORIG = new DemoTableWarehouseMib(DefaultMOFactory.getInstance());
        // Tables
        warehouseEntry = new FTable("warehouseEntry", mibORIG.getWarehouseEntry(), agent,
            COLUMN_WarehouseItemBrand,
            COLUMN_WarehouseItemName,
            COLUMN_WarehouseItemPrice,
            COLUMN_WarehouseRowStatus);
        addNode(warehouseEntry);
    } // init()

    @Override
    public void registerMOs(MOServer server, OctetString context)
    throws DuplicateRegistrationException
    {
        mibORIG.registerMOs(server, context);
    } // registerMOs()

    @Override
    public void unregisterMOs(MOServer server, OctetString context) {
        mibORIG.unregisterMOs(server, context);
    } // unregisterMOs()

    public FTable getWarehouseEntry() {
        return warehouseEntry;
    } // getWarehouseEntry()

} // class DemoTableWarehouseMibFriend
