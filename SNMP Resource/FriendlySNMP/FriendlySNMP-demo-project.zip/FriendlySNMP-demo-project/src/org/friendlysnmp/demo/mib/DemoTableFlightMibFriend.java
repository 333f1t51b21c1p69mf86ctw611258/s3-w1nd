/*
 * File: DemoTableFlightMibFriend.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo.mib;

import org.friendlysnmp.AgentWorker;
import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FTable;
import org.friendlysnmp.mib.BaseMib;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOServer;
import org.snmp4j.agent.mo.DefaultMOFactory;
import org.snmp4j.smi.OctetString;

public class DemoTableFlightMibFriend extends BaseMib {

    private DemoTableFlightMib mibORIG;

    // Tables
    private FTable flightEntry;

    // Columns for table flightEntry
    public final static FColumn COLUMN_FlightCarrier = 
        new FColumn("FlightCarrier",
                DemoTableFlightMib.idxFlightCarrier, 
                DemoTableFlightMib.colFlightCarrier);
    public final static FColumn COLUMN_FlightNumber = 
        new FColumn("FlightNumber",
                DemoTableFlightMib.idxFlightNumber, 
                DemoTableFlightMib.colFlightNumber);
    public final static FColumn COLUMN_FlightDestination = 
        new FColumn("FlightDestination",
                DemoTableFlightMib.idxFlightDestination, 
                DemoTableFlightMib.colFlightDestination);
    public final static FColumn COLUMN_FlightDepartTime = 
        new FColumn("FlightDepartTime",
                DemoTableFlightMib.idxFlightDepartTime, 
                DemoTableFlightMib.colFlightDepartTime);
    public final static FColumn COLUMN_FlightStatus = 
        new FColumn("FlightStatus",
                DemoTableFlightMib.idxFlightStatus, 
                DemoTableFlightMib.colFlightStatus);
    public final static FColumn COLUMN_FlightRowStatus = 
        new FColumn("FlightRowStatus",
                DemoTableFlightMib.idxFlightRowStatus, 
                DemoTableFlightMib.colFlightRowStatus);

    public DemoTableFlightMibFriend() {
        super();
    } // DemoTableFlightMibFriend()

    @Override
    public void init(AgentWorker agent) throws FException {
        super.init(agent);
        mibORIG = new DemoTableFlightMib(DefaultMOFactory.getInstance());
        // Tables
        flightEntry = new FTable("flightEntry", mibORIG.getFlightEntry(), agent,
            COLUMN_FlightCarrier,
            COLUMN_FlightNumber,
            COLUMN_FlightDestination,
            COLUMN_FlightDepartTime,
            COLUMN_FlightStatus,
            COLUMN_FlightRowStatus);
        addNode(flightEntry);
    } // init()

    @Override
    public void registerMOs(MOServer server, OctetString context)
    throws DuplicateRegistrationException
    {
        mibORIG.registerMOs(server, context);
    } // registerMOs()

    @Override
    public void unregisterMOs(MOServer server, OctetString context) {
        mibORIG.unregisterMOs(server, context);
    } // unregisterMOs()

    public FTable getFlightEntry() {
        return flightEntry;
    } // getFlightEntry()

} // class DemoTableFlightMibFriend
