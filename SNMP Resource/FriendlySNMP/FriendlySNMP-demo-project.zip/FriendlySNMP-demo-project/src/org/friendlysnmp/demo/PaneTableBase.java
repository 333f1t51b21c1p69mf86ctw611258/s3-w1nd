/*
 * File: PaneTableBase.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.FException;

@SuppressWarnings("serial")
public abstract class PaneTableBase extends PaneBase 
implements ListSelectionListener, ActionListener {

    protected JTable table;
    protected TableModelBase dataModel;
    private JButton btnAdd, btnDelete;
    
    public PaneTableBase(TableModelBase dataModel) {
        this.dataModel = dataModel;
    } // PaneTableBase()
    
    @Override
    public void initGUI() {
        super.initGUI();
        dataModel.updateColumnModel(table.getColumnModel());
    } // initGUI()

    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        
        // === TABLE ===
        table = new JTable(dataModel);
        table.setCellSelectionEnabled(true);
        table.getSelectionModel().addListSelectionListener(this);
        //table.getColumnModel().getColumn(COL_OID).setPreferredWidth(180);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(0,5,5,5), // T,L,B,R
                BorderFactory.createBevelBorder(BevelBorder.LOWERED)));
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // === BUTTONS ===
        JPanel panelBtn = new JPanel();
        btnAdd    = createBtn(panelBtn, "Add Row");
        btnDelete = createBtn(panelBtn, "Delete Row");
        panel.add(panelBtn, BorderLayout.SOUTH);
        
        // === UPDATE ===
        updateEnable();
        return panel;
    } // getContentPanel()

    @Override
    public void initSNMP(FriendlyAgent agent) throws FException {
        dataModel.initSNMP(agent);
    } // initSNMP()
    
    private JButton createBtn(JPanel panel, String label) {
        JButton btn = new JButton(label);
        btn.addActionListener(this);
        panel.add(btn);
        return btn;
    } // createBtn()

    private void updateEnable() {
        btnDelete.setEnabled(table.getSelectedRow() >= 0);
    } // updateEnable()
    
    public void valueChanged(ListSelectionEvent e) {
        // implements ListSelectionListener
        updateEnable();
    } // valueChanged()

    public void actionPerformed(ActionEvent e) {
        Object objSource = e.getSource();
        int rowSel = table.getSelectedRow();
        try {
            if (objSource == btnAdd) {
                rowSel = dataModel.addRow();
            }
            if (objSource == btnDelete) {
                rowSel = dataModel.deleteRow(rowSel);
            }
        } catch (FException e1) {
        }
        int colSel = table.getSelectedColumn(); // before table change
        if (colSel < 0) {
            colSel = 0;
        }
        dataModel.fireTableDataChanged();
        if (rowSel >= 0) {
            table.setRowSelectionInterval(rowSel, rowSel);
            table.setColumnSelectionInterval(colSel, colSel);
        }
    } // actionPerformed()
    
} // class PaneTableBase
