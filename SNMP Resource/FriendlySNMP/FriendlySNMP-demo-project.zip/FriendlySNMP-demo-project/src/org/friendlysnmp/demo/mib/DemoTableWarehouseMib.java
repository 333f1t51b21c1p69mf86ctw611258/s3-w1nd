 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoTableWarehouseMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoTableWarehouseMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoTableWarehouseMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,5 });

  // Identities
  // Scalars
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_DEMO_TABLE_WAREHOUSE_MIB = "DEMO-TABLE-WAREHOUSE-MIB";
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DISPLAYSTRING = "DisplayString";
  private static final String TC_DEMOPRICETC = "DemoPriceTC";
  private static final String TC_ROWSTATUS = "RowStatus";

  // Scalars

  // Tables
  public static final OID oidWarehouseEntry = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,5,1,9,1 });

  // Index OID definitions
  public static final OID oidWarehouseDepartmentIndex =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,5,1,9,1,2 });
  public static final OID oidWarehouseItemIndex =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,5,1,9,1,3 });

  // Column TC definitions for warehouseEntry:
  public static final String tcModuleSNMPv2Tc = "SNMPv2-TC";
  public static final String tcDefDisplayString = "DisplayString";
  public static final String tcModuleDemoTableWarehouseMib = "DEMO-TABLE-WAREHOUSE-MIB";
  public static final String tcDefDemoPriceTC = "DemoPriceTC";
  public static final String tcDefRowStatus = "RowStatus";
    
  // Column sub-identifier definitions for warehouseEntry:
  public static final int colWarehouseItemBrand = 8;
  public static final int colWarehouseItemName = 12;
  public static final int colWarehouseItemPrice = 18;
  public static final int colWarehouseRowStatus = 40;

  // Column index definitions for warehouseEntry:
  public static final int idxWarehouseItemBrand = 0;
  public static final int idxWarehouseItemName = 1;
  public static final int idxWarehouseItemPrice = 2;
  public static final int idxWarehouseRowStatus = 3;

  private MOTableSubIndex[] warehouseEntryIndexes;
  private MOTableIndex warehouseEntryIndex;
  
  private MOTable<WarehouseEntryRow,
                  MOColumn,
                  MOTableModel<WarehouseEntryRow>> warehouseEntry;
  private MOTableModel<WarehouseEntryRow> warehouseEntryModel;


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoTableWarehouseMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoTableWarehouseMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoTableWarehouseMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoTableWarehouseMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    createWarehouseEntry(moFactory);
  }



  public MOTable<WarehouseEntryRow,MOColumn,MOTableModel<WarehouseEntryRow>> getWarehouseEntry() {
    return warehouseEntry;
  }


  @SuppressWarnings(value={"unchecked"})
  private void createWarehouseEntry(MOFactory moFactory) {
    // Index definition
    warehouseEntryIndexes = 
      new MOTableSubIndex[] {
      moFactory.createSubIndex(oidWarehouseDepartmentIndex, 
                               SMIConstants.SYNTAX_INTEGER, 1, 1),
      moFactory.createSubIndex(oidWarehouseItemIndex, 
                               SMIConstants.SYNTAX_INTEGER, 1, 1)    };

    warehouseEntryIndex = 
      moFactory.createIndex(warehouseEntryIndexes,
                            false,
                            new MOTableIndexValidator() {
      public boolean isValidIndex(OID index) {
        boolean isValidIndex = true;
     //--AgentGen BEGIN=warehouseEntry::isValidIndex
     //--AgentGen END
        return isValidIndex;
      }
    });

    // Columns
    MOColumn[] warehouseEntryColumns = new MOColumn[4];
    warehouseEntryColumns[idxWarehouseItemBrand] = 
      new DisplayString(colWarehouseItemBrand,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint warehouseItemBrandVC = new ConstraintsImpl();
    ((ConstraintsImpl)warehouseItemBrandVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemBrand]).
      addMOValueValidationListener(new ValueConstraintValidator(warehouseItemBrandVC));                                  
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemBrand]).
      addMOValueValidationListener(new WarehouseItemBrandValidator());
    warehouseEntryColumns[idxWarehouseItemName] = 
      new DisplayString(colWarehouseItemName,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint warehouseItemNameVC = new ConstraintsImpl();
    ((ConstraintsImpl)warehouseItemNameVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemName]).
      addMOValueValidationListener(new ValueConstraintValidator(warehouseItemNameVC));                                  
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemName]).
      addMOValueValidationListener(new WarehouseItemNameValidator());
    warehouseEntryColumns[idxWarehouseItemPrice] = 
      new MOMutableColumn<Integer32>(colWarehouseItemPrice,
                          SMIConstants.SYNTAX_INTEGER32,
                          moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                          (Integer32)null);
    ValueConstraint warehouseItemPriceVC = new ConstraintsImpl();
    ((ConstraintsImpl)warehouseItemPriceVC).add(new Constraint(0L, 2147483647L));
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemPrice]).
      addMOValueValidationListener(new ValueConstraintValidator(warehouseItemPriceVC));                                  
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseItemPrice]).
      addMOValueValidationListener(new WarehouseItemPriceValidator());
    warehouseEntryColumns[idxWarehouseRowStatus] = 
      new RowStatus(colWarehouseRowStatus);
    ValueConstraint warehouseRowStatusVC = new EnumerationConstraint(
      new int[] { 1,
                  2,
                  3,
                  4,
                  5,
                  6 });
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseRowStatus]).
      addMOValueValidationListener(new ValueConstraintValidator(warehouseRowStatusVC));                                  
    ((MOMutableColumn)warehouseEntryColumns[idxWarehouseRowStatus]).
      addMOValueValidationListener(new WarehouseRowStatusValidator());
    // Table model
    warehouseEntryModel = (MOTableModel<WarehouseEntryRow>)
      moFactory.createTableModel(oidWarehouseEntry,
                                 warehouseEntryIndex,
                                 warehouseEntryColumns);
    ((MOMutableTableModel<WarehouseEntryRow>)warehouseEntryModel).setRowFactory(
      new WarehouseEntryRowFactory());
    warehouseEntry = 
      moFactory.createTable(oidWarehouseEntry,
                            warehouseEntryIndex,
                            warehouseEntryColumns,
                            warehouseEntryModel);
  }



  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.warehouseEntry, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.warehouseEntry, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars

  // Value Validators

  /**
   * The <code>WarehouseItemBrandValidator</code> implements the value
   * validation for <code>WarehouseItemBrand</code>.
   */
  static class WarehouseItemBrandValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=warehouseItemBrand::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>WarehouseItemNameValidator</code> implements the value
   * validation for <code>WarehouseItemName</code>.
   */
  static class WarehouseItemNameValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=warehouseItemName::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>WarehouseItemPriceValidator</code> implements the value
   * validation for <code>WarehouseItemPrice</code>.
   */
  static class WarehouseItemPriceValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      long v = ((Integer32)newValue).getValue();
      if (!(((v >= 0L) && (v <= 2147483647L)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_VALUE);
        return;
      }
     //--AgentGen BEGIN=warehouseItemPrice::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>WarehouseRowStatusValidator</code> implements the value
   * validation for <code>WarehouseRowStatus</code>.
   */
  static class WarehouseRowStatusValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
     //--AgentGen BEGIN=warehouseRowStatus::validate
     //--AgentGen END
    }
  }

  // Rows and Factories

  public class WarehouseEntryRow extends DefaultMOMutableRow2PC {

     //--AgentGen BEGIN=warehouseEntry::RowMembers
     //--AgentGen END

    public WarehouseEntryRow(OID index, Variable[] values) {
      super(index, values);
     //--AgentGen BEGIN=warehouseEntry::RowConstructor
     //--AgentGen END
    }
    
    public OctetString getWarehouseItemBrand() {
     //--AgentGen BEGIN=warehouseEntry::getWarehouseItemBrand
     //--AgentGen END
      return (OctetString) super.getValue(idxWarehouseItemBrand);
    }  
    
    public void setWarehouseItemBrand(OctetString newValue) {
     //--AgentGen BEGIN=warehouseEntry::setWarehouseItemBrand
     //--AgentGen END
      super.setValue(idxWarehouseItemBrand, newValue);
    }
    
    public OctetString getWarehouseItemName() {
     //--AgentGen BEGIN=warehouseEntry::getWarehouseItemName
     //--AgentGen END
      return (OctetString) super.getValue(idxWarehouseItemName);
    }  
    
    public void setWarehouseItemName(OctetString newValue) {
     //--AgentGen BEGIN=warehouseEntry::setWarehouseItemName
     //--AgentGen END
      super.setValue(idxWarehouseItemName, newValue);
    }
    
    public Integer32 getWarehouseItemPrice() {
     //--AgentGen BEGIN=warehouseEntry::getWarehouseItemPrice
     //--AgentGen END
      return (Integer32) super.getValue(idxWarehouseItemPrice);
    }  
    
    public void setWarehouseItemPrice(Integer32 newValue) {
     //--AgentGen BEGIN=warehouseEntry::setWarehouseItemPrice
     //--AgentGen END
      super.setValue(idxWarehouseItemPrice, newValue);
    }
    
    public Integer32 getWarehouseRowStatus() {
     //--AgentGen BEGIN=warehouseEntry::getWarehouseRowStatus
     //--AgentGen END
      return (Integer32) super.getValue(idxWarehouseRowStatus);
    }  
    
    public void setWarehouseRowStatus(Integer32 newValue) {
     //--AgentGen BEGIN=warehouseEntry::setWarehouseRowStatus
     //--AgentGen END
      super.setValue(idxWarehouseRowStatus, newValue);
    }
    
    public Variable getValue(int column) {
     //--AgentGen BEGIN=warehouseEntry::RowGetValue
     //--AgentGen END
      switch(column) {
        case idxWarehouseItemBrand: 
        	return getWarehouseItemBrand();
        case idxWarehouseItemName: 
        	return getWarehouseItemName();
        case idxWarehouseItemPrice: 
        	return getWarehouseItemPrice();
        case idxWarehouseRowStatus: 
        	return getWarehouseRowStatus();
        default:
          return super.getValue(column);
      }
    }
    
    public void setValue(int column, Variable value) {
     //--AgentGen BEGIN=warehouseEntry::RowSetValue
     //--AgentGen END
      switch(column) {
        case idxWarehouseItemBrand: 
        	setWarehouseItemBrand((OctetString)value);
        	break;
        case idxWarehouseItemName: 
        	setWarehouseItemName((OctetString)value);
        	break;
        case idxWarehouseItemPrice: 
        	setWarehouseItemPrice((Integer32)value);
        	break;
        case idxWarehouseRowStatus: 
        	setWarehouseRowStatus((Integer32)value);
        	break;
        default:
          super.setValue(column, value);
      }
    }

     //--AgentGen BEGIN=warehouseEntry::Row
     //--AgentGen END
  }
  
  class WarehouseEntryRowFactory 
        implements MOTableRowFactory<WarehouseEntryRow>
  {
    public synchronized WarehouseEntryRow createRow(OID index, Variable[] values)
        throws UnsupportedOperationException 
    {
      WarehouseEntryRow row = 
        new WarehouseEntryRow(index, values);
     //--AgentGen BEGIN=warehouseEntry::createRow
     //--AgentGen END
      return row;
    }
    
    public synchronized void freeRow(WarehouseEntryRow row) {
     //--AgentGen BEGIN=warehouseEntry::freeRow
     //--AgentGen END
    }

     //--AgentGen BEGIN=warehouseEntry::RowFactory
     //--AgentGen END
  }


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoTableWarehouseMib
  protected void addTCsToFactory(MOFactory moFactory) {
   moFactory.addTextualConvention(new DemoPriceTC()); 
  }


  public class DemoPriceTC implements TextualConvention {
  	
    public DemoPriceTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_TABLE_WAREHOUSE_MIB;
    }
  	
    public String getName() {
      return TC_DEMOPRICETC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
      	((AssignableFromLong)v).setValue(0L);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoPriceTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new ConstraintsImpl();
      ((ConstraintsImpl)vc).add(new Constraint(0L, 2147483647L));
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoPriceTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new ConstraintsImpl();
        ((ConstraintsImpl)vc).add(new Constraint(0L, 2147483647L));
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoPriceTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


