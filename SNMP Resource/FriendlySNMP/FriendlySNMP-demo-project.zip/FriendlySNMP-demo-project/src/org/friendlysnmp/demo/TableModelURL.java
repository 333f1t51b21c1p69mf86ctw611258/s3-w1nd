/*
 * File: TableModelURL.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import javax.swing.table.TableColumnModel;

import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FID;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.demo.mib.DemoTableUrlMibFriend;

@SuppressWarnings("serial")
public class TableModelURL extends TableModelBase {

    // Column indices
    final static public int COL_OID       = 0;
    final static public int COL_HOSTNAME  = 1;
    final static public int COL_IPADDRESS = 2;
    final static public int COL_RESPONSE  = 3;
    final static private int COL_LAST     = 4;

    // Column header names
    final static private String[] HEADERS = new String[COL_LAST];
    static {
        HEADERS[COL_OID      ] = "Index";
        HEADERS[COL_HOSTNAME ] = "Host Name";
        HEADERS[COL_IPADDRESS] = "IP Address";
        HEADERS[COL_RESPONSE ] = "Response Time (ms)";
    }

    @Override
    public void updateColumnModel(TableColumnModel columnModel) {
        setColumnFixedWidth(columnModel, COL_OID, 60);
    } // updateColumnModel()
    
    @Override
    public void initSNMP(FriendlyAgent agent) throws FException {
        DemoTableUrlMibFriend mib = new DemoTableUrlMibFriend();
        agent.addMIB(mib);
        
        table = mib.getUrlEntry();
        try {
            table.setDefaultValues("?", "0.0.0.0", 0);
        } catch (FException e) {
            throw new IllegalArgumentException();
        }
        
        try {
            //        Host Name          IP address   Response (ms)
            loadRow("www.google.com",  "64.233.161.99",  34);
            loadRow("www.yahoo.com",   "69.147.114.210", 53);
            loadRow("www.hotmail.com", "216.74.180.189", 20);
            loadRow("msnbc.msn.com",   "207.46.150.51",  220);
        } catch (FException e) {
            ErrorPresenter.showError(e, "Cannot load URL data");
        }
    } // initSNMP()

    private void loadRow(String hostname, String ipAddress, int responseTime) 
    throws FException 
    {
        // Load data directly into the agent
        FID idRow = table.addRowNext();
        table.setValueAt(hostname,     
                idRow, DemoTableUrlMibFriend.COLUMN_UrlHostName);
        table.setValueAt(ipAddress,    
                idRow, DemoTableUrlMibFriend.COLUMN_UrlIpAddress);
        table.setValueAt(responseTime, 
                idRow, DemoTableUrlMibFriend.COLUMN_UrlResponseTime);
    } // loadRow()    
    
    public int getColumnCount() {
        // Implements AbstractTableModel
        return HEADERS.length;
    }

    @Override
    public String getColumnName(int indexCol) {
        return HEADERS[indexCol];
    }
    
    public int getRowCount() {
        // Implements AbstractTableModel
        return table.getRowCount();
    }

    @Override
    public boolean isCellEditable(int indexRow, int indexCol) {
        switch (indexCol) {
            case COL_OID:
                return false;
            case COL_HOSTNAME: 
            case COL_IPADDRESS:
            case COL_RESPONSE:
                return true;
            default: 
                throw new IllegalArgumentException("Not valid column: " + indexCol);
        }
    } // isCellEditable()
    
    public Object getValueAt(int indexRow, int indexCol) {
        // Implements AbstractTableModel
        try {
            FID idRow = table.getRowID(indexRow);
            switch (indexCol) {
                case COL_OID:
                    //return table.getRowIndex(idRow);
                    return idRow.getOID();
                case COL_HOSTNAME: 
                case COL_IPADDRESS:
                case COL_RESPONSE:
                    return table.getValueAt(idRow, convertColumnToMib(indexCol));
                default: 
                    throw new IllegalArgumentException("Not valid column: " + indexCol);
            }
        } catch (FException e) {
            ErrorPresenter.showError(e);
            return null;
        }
    } // getValueAt()

    @Override
    public void setValueAt(Object val, int indexRow, int indexCol) {
        try {
            switch (indexCol) {
                case COL_HOSTNAME: 
                case COL_IPADDRESS:
                case COL_RESPONSE:
                    FID idRow = table.getRowID(indexRow);
                    table.setValueAt(val, idRow, convertColumnToMib(indexCol));
                    break;
                default: 
                    throw new IllegalArgumentException("Not valid column: " + indexCol);
            }
        } catch (FException e) {
            ErrorPresenter.showError(e);
        }
    } // setValueAt()
    
    private FColumn convertColumnToMib(int indexCol) {
        switch (indexCol) {
            case COL_HOSTNAME:  return DemoTableUrlMibFriend.COLUMN_UrlHostName; 
            case COL_IPADDRESS: return DemoTableUrlMibFriend.COLUMN_UrlIpAddress;
            case COL_RESPONSE:  return DemoTableUrlMibFriend.COLUMN_UrlResponseTime;
            default: 
                throw new IllegalArgumentException("Not valid column: " + indexCol);
        }
    } // convertColumnToMib()

    @Override
    public int addRow() throws FException {
        FID idRowNewSelection = table.addRowNext();
        return table.getRowIndex(idRowNewSelection);
    } // addRow()

    @Override
    public int deleteRow(int indexRow) throws FException {
        FID idRow = table.getRowID(indexRow);
        FID idRowNewSelection = table.deleteRow(idRow); 
        return table.getRowIndex(idRowNewSelection);
    } // deleteRow()

} // class TableModelURL
