 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoScalarRwMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoScalarRwMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoScalarRwMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,2 });

  // Identities
  // Scalars
  public static final OID oidImageFilename = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,2,1,1,0 });
  public static final OID oidImageFormat = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,2,1,2,0 });
  public static final OID oidImageSize = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,2,1,3,0 });
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_DEMO_SCALAR_RW_MIB = "DEMO-SCALAR-RW-MIB";
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DEMOIMAGEFORMATTC = "DemoImageFormatTC";
  private static final String TC_DISPLAYSTRING = "DisplayString";

  // Scalars
  private MOScalar<OctetString> imageFilename;
  private MOScalar<Integer32> imageFormat;
  private MOScalar<OctetString> imageSize;

  // Tables


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoScalarRwMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoScalarRwMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoScalarRwMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoScalarRwMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    imageFilename = 
      new ImageFilename(oidImageFilename, 
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_WRITE));
    imageFilename.addMOValueValidationListener(new ImageFilenameValidator());
    imageFormat = 
      new ImageFormat(oidImageFormat, 
                      moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_WRITE));
    imageFormat.addMOValueValidationListener(new ImageFormatValidator());
    imageSize = 
      new ImageSize(oidImageSize, 
                    moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_WRITE));
    imageSize.addMOValueValidationListener(new ImageSizeValidator());
  }

  public MOScalar<OctetString> getImageFilename() {
    return imageFilename;
  }
  public MOScalar<Integer32> getImageFormat() {
    return imageFormat;
  }
  public MOScalar<OctetString> getImageSize() {
    return imageSize;
  }




  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.imageFilename, context);
    server.register(this.imageFormat, context);
    server.register(this.imageSize, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.imageFilename, context);
    server.unregister(this.imageFormat, context);
    server.unregister(this.imageSize, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars
  public class ImageFilename extends DisplayStringScalar<OctetString> {
    ImageFilename(OID oid, MOAccess access) {
      super(oid, access, new OctetString(),
            0, 
            255);
//--AgentGen BEGIN=imageFilename
//--AgentGen END
    }

    public int isValueOK(SubRequest request) {
      Variable newValue =
        request.getVariableBinding().getVariable();
      int valueOK = super.isValueOK(request);
      if (valueOK != SnmpConstants.SNMP_ERROR_SUCCESS) {
      	return valueOK;
      }
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        valueOK = SnmpConstants.SNMP_ERROR_WRONG_LENGTH;
      }
     //--AgentGen BEGIN=imageFilename::isValueOK
     //--AgentGen END
      return valueOK; 
    }

    public OctetString getValue() {
     //--AgentGen BEGIN=imageFilename::getValue
     //--AgentGen END
      return super.getValue();    
    }

    public int setValue(OctetString newValue) {
     //--AgentGen BEGIN=imageFilename::setValue
     //--AgentGen END
      return super.setValue(newValue);    
    }

     //--AgentGen BEGIN=imageFilename::_METHODS
     //--AgentGen END

  }

  public class ImageFormat extends MOScalar<Integer32> {
    ImageFormat(OID oid, MOAccess access) {
      super(oid, access, new Integer32());
//--AgentGen BEGIN=imageFormat
//--AgentGen END
    }

    public int isValueOK(SubRequest request) {
      Variable newValue =
        request.getVariableBinding().getVariable();
      int valueOK = super.isValueOK(request);
      if (valueOK != SnmpConstants.SNMP_ERROR_SUCCESS) {
      	return valueOK;
      }
     //--AgentGen BEGIN=imageFormat::isValueOK
     //--AgentGen END
      return valueOK; 
    }

    public Integer32 getValue() {
     //--AgentGen BEGIN=imageFormat::getValue
     //--AgentGen END
      return super.getValue();    
    }

    public int setValue(Integer32 newValue) {
     //--AgentGen BEGIN=imageFormat::setValue
     //--AgentGen END
      return super.setValue(newValue);    
    }

     //--AgentGen BEGIN=imageFormat::_METHODS
     //--AgentGen END

  }

  public class ImageSize extends DisplayStringScalar<OctetString> {
    ImageSize(OID oid, MOAccess access) {
      super(oid, access, new OctetString(),
            0, 
            255);
//--AgentGen BEGIN=imageSize
//--AgentGen END
    }

    public int isValueOK(SubRequest request) {
      Variable newValue =
        request.getVariableBinding().getVariable();
      int valueOK = super.isValueOK(request);
      if (valueOK != SnmpConstants.SNMP_ERROR_SUCCESS) {
      	return valueOK;
      }
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        valueOK = SnmpConstants.SNMP_ERROR_WRONG_LENGTH;
      }
     //--AgentGen BEGIN=imageSize::isValueOK
     //--AgentGen END
      return valueOK; 
    }

    public OctetString getValue() {
     //--AgentGen BEGIN=imageSize::getValue
     //--AgentGen END
      return super.getValue();    
    }

    public int setValue(OctetString newValue) {
     //--AgentGen BEGIN=imageSize::setValue
     //--AgentGen END
      return super.setValue(newValue);    
    }

     //--AgentGen BEGIN=imageSize::_METHODS
     //--AgentGen END

  }


  // Value Validators
  /**
   * The <code>ImageFilenameValidator</code> implements the value
   * validation for <code>ImageFilename</code>.
   */
  static class ImageFilenameValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=imageFilename::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>ImageFormatValidator</code> implements the value
   * validation for <code>ImageFormat</code>.
   */
  static class ImageFormatValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
     //--AgentGen BEGIN=imageFormat::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>ImageSizeValidator</code> implements the value
   * validation for <code>ImageSize</code>.
   */
  static class ImageSizeValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=imageSize::validate
     //--AgentGen END
    }
  }


  // Rows and Factories


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoScalarRwMib
  protected void addTCsToFactory(MOFactory moFactory) {
   moFactory.addTextualConvention(new DemoImageFormatTC()); 
  }


  public class DemoImageFormatTC implements TextualConvention {
    public static final int bmp = 2;
    public static final int jpg = 3;
    public static final int gif = 5;
    public static final int png = 12;
  	
    public DemoImageFormatTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_SCALAR_RW_MIB;
    }
  	
    public String getName() {
      return TC_DEMOIMAGEFORMATTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
        ((AssignableFromLong)v).setValue(2);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoImageFormatTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new EnumerationConstraint(
        new int[] { bmp,
                    jpg,
                    gif,
                    png });
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoImageFormatTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new EnumerationConstraint(
          new int[] { bmp,
                      jpg,
                      gif,
                      png });
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoImageFormatTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


