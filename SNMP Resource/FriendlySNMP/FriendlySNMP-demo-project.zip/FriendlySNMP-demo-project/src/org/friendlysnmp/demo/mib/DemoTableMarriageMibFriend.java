/*
 * File: DemoTableMarriageMibFriend.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo.mib;

import org.friendlysnmp.AgentWorker;
import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FTable;
import org.friendlysnmp.mib.BaseMib;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOServer;
import org.snmp4j.agent.mo.DefaultMOFactory;
import org.snmp4j.smi.OctetString;

public class DemoTableMarriageMibFriend extends BaseMib {

    private DemoTableMarriageMib mibORIG;

    // Tables
    private FTable marriageEntry;

    // Columns for table marriageEntry
    public final static FColumn COLUMN_MarriageYear = 
        new FColumn("MarriageYear",
                DemoTableMarriageMib.idxMarriageYear, 
                DemoTableMarriageMib.colMarriageYear);
    public final static FColumn COLUMN_MarriageCity = 
        new FColumn("MarriageCity",
                DemoTableMarriageMib.idxMarriageCity, 
                DemoTableMarriageMib.colMarriageCity);
    public final static FColumn COLUMN_MarriageRowStatus = 
        new FColumn("MarriageRowStatus",
                DemoTableMarriageMib.idxMarriageRowStatus, 
                DemoTableMarriageMib.colMarriageRowStatus);

    public DemoTableMarriageMibFriend() {
        super();
    } // DemoTableMarriageMibFriend()

    @Override
    public void init(AgentWorker agent) throws FException {
        super.init(agent);
        mibORIG = new DemoTableMarriageMib(DefaultMOFactory.getInstance());
        // Tables
        marriageEntry = new FTable("marriageEntry", mibORIG.getMarriageEntry(), agent,
            COLUMN_MarriageYear,
            COLUMN_MarriageCity,
            COLUMN_MarriageRowStatus);
        addNode(marriageEntry);
    } // init()

    @Override
    public void registerMOs(MOServer server, OctetString context)
    throws DuplicateRegistrationException
    {
        mibORIG.registerMOs(server, context);
    } // registerMOs()

    @Override
    public void unregisterMOs(MOServer server, OctetString context) {
        mibORIG.unregisterMOs(server, context);
    } // unregisterMOs()

    public FTable getMarriageEntry() {
        return marriageEntry;
    } // getMarriageEntry()

} // class DemoTableMarriageMibFriend
