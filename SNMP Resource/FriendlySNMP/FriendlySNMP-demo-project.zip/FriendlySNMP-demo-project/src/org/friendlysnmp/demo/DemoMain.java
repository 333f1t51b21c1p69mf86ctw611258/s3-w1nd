/*
 * File: DemoMain.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.friendlysnmp.FConstant;
import org.friendlysnmp.FException;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.event.FExceptionListener;
import org.friendlysnmp.event.UncaughtExceptionListener;
import org.snmp4j.log.Log4jLogFactory;
import org.snmp4j.log.LogFactory;

@SuppressWarnings("serial")
public class DemoMain extends JFrame {
    
    //private static final Logger logger = Logger.getLogger(DemoMain.class);
    private static final String TITLE = "Demo FriendlySNMP";
    private static final String VERSION = "$Revision: 1.32 $";
    private static final String PROP_FILE = "demo.properties";
    private final static String HOME_URL = "http://www.friendlysnmp.org";
    
    private JPanel panelDemo;
    private List<PaneBase> lstPanes; 
    private Properties propApp;
    private FriendlyAgent agentSNMP; 
    private PaneAbout paneAbout;
    private JTextField labelURL;
    
    static {
        // Initialize Log4j logging for SNMP4J library
        LogFactory.setLogFactory(new Log4jLogFactory());
        
        // Initialize LookAndFeel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Ignore: ClassNotFoundException, InstantiationException
            //         IllegalAccessException, UnsupportedLookAndFeelException
        }
    }
    
    private DemoMain() {
        setSize(750, 450);

        Dimension dmScreen = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension dmWindow = getSize();
        int w = Math.min(dmWindow.width, dmScreen.width);
        int h = Math.min(dmWindow.height, dmScreen.height - 20); // 20 for taskbar
        int x = (dmScreen.width - w) / 2;
        int y = (dmScreen.height - h) / 2;
        setBounds(x, y, w, h);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                doClose();
            }
        });
        
        lstPanes = new ArrayList<PaneBase>();
        lstPanes.add(paneAbout = new PaneAbout());
        lstPanes.add(new Pane01ScalarRO());
        lstPanes.add(new Pane02ScalarRW());
        lstPanes.add(new Pane03TableStatic());
        lstPanes.add(new Pane04TableDynamic());
        lstPanes.add(new Pane05TableTwoIndex());
        lstPanes.add(new Pane06TableTextIndex());
        lstPanes.add(new Pane07Notification());
        lstPanes.add(new Pane08Deadlock());
        lstPanes.add(new Pane09UncaughtExc());
        lstPanes.add(new Pane10CaughtExc());
        lstPanes.add(new Pane11Agent());
    } // DemoMain()

    private void initGUI() {
        setTitle(TITLE);
        Container cont = this.getContentPane();
        cont.setLayout(new BorderLayout());
        cont.add(createRightPane(), BorderLayout.CENTER);
        cont.add(createLeftPane(lstPanes.toArray(new PaneBase[lstPanes.size()])), BorderLayout.WEST);
        for (PaneBase pane : lstPanes) {
            pane.initGUI();
        }
        paneAbout.setProperties(propApp);
    } // initGUI()

    private Component createRightPane() {
        panelDemo = new JPanel(new BorderLayout());
        panelDemo.setBorder(BorderFactory.createEmptyBorder(5,5,5,5)); // T,L,B,R
        return panelDemo;
    } // createRightPane()
    
    private Component createLeftPane(PaneBase[] arPane) {
        JPanel panelLeft = new JPanel(new BorderLayout());
        panelLeft.add(new JLabel("Select demo"), BorderLayout.NORTH);
        panelLeft.setBorder(BorderFactory.createEmptyBorder(5,10,5,10)); // T,L,B,R
        
        // List of panes
        JList<PaneBase> lst = new JList<PaneBase>(arPane);
        JScrollPane sp = new JScrollPane(lst, 
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panelLeft.add(sp, BorderLayout.CENTER);
        lst.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                @SuppressWarnings("unchecked")
                JList<PaneBase> lst = (JList<PaneBase>)e.getSource();
                PaneBase pane = lst.getSelectedValue();
                loadPane(pane);
            }
        });
        lst.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createBevelBorder(BevelBorder.LOWERED),
                BorderFactory.createEmptyBorder(5,5,5,5)
                ));
        lst.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lst.setSelectedIndex(0);
        
        // Link and Close button
        JPanel panelBtm = new JPanel();
        panelBtm.setLayout(new BoxLayout(panelBtm, BoxLayout.Y_AXIS));
        
        labelURL = new JTextField(HOME_URL);
        labelURL.setForeground(Color.BLUE);
        labelURL.setEditable(false);
        labelURL.setBorder(null);
        labelURL.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                openHome();
            }
            public void mouseEntered(MouseEvent e) {
                labelURL.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(MouseEvent e) {
                labelURL.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        });
        
        JTextArea taHome = new JTextArea("Visit for downloads and documentation:");
        taHome.setLineWrap(true);
        taHome.setWrapStyleWord(true);
        taHome.setEditable(false);
        taHome.setBackground(labelURL.getBackground());
        taHome.setFont(labelURL.getFont());
        
        panelBtm.add(taHome);
        panelBtm.add(labelURL);
        
        JPanel panelClose = new JPanel();
        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doClose();
            }
        });
        panelClose.add(btnClose);
        panelBtm.add(panelClose);
        
        panelLeft.add(panelBtm, BorderLayout.SOUTH);
        
        return panelLeft;
    } // createLeftPane()

    private void loadPane(PaneBase pane) {
        panelDemo.removeAll();
        panelDemo.add(pane, BorderLayout.CENTER);
        validate();
        repaint();
    } // loadPane()
    
    private void initSNMP() {
        try {
            // Second instance of the application throws exception:
            //    java.net.BindException: Address already in use: Cannot bind
            propApp = FriendlyAgent.loadProps(DemoMain.class, PROP_FILE);
            propApp.put(FConstant.PREFIX_APP + "customer", "FriendlySNMP community");
            propApp.put(FConstant.PREFIX_DEPENDENCY + "log4j", "v1.2.14");
            propApp.put(FConstant.PREFIX_DEPENDENCY + "slf4j", "v1.5.11");
            
            String version = VERSION.replace('$', ' ').trim();
            agentSNMP = new FriendlyAgent(TITLE, version, propApp);
            agentSNMP.addUncaughtExceptionListener(new UncaughtExceptionListener() {
                public void uncaughtException(Thread t, Throwable e) {
                    ErrorPresenter.showError(e, "Uncaught exception in Demo application");
                }
            });
            for (PaneBase pane : lstPanes) {
                pane.initSNMP(agentSNMP);
            }
            agentSNMP.init();
            agentSNMP.start();
            // Add exception listener *after* successful agent init
            agentSNMP.addFExceptionListener(new FExceptionListener() {
                public void exceptionThrown(String msg, FException e) {
                    ErrorPresenter.showError(e, msg);
                }
            });
        } catch (Throwable e) {
            // FException and any RuntimeException
            ErrorPresenter.showError(e, "Cannot init SNMP agent");
            doClose();
            return;
        }
    } // initSNMP()
    
    private void openHome() {
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    desktop.browse(new URI(HOME_URL));
                }
                catch(Exception e) {
                    // IOException, URISyntaxException
                    // Do nothing
                }
            }
        }
    }
    
    private void doClose() {
        System.exit(0);
    } // doClose()
    
    public static void main(String[] args) {
        DemoMain app = new DemoMain();
        app.initSNMP();
        app.initGUI();
        app.toFront();
        app.setVisible(true);
    } // main()

} // class DemoMain
