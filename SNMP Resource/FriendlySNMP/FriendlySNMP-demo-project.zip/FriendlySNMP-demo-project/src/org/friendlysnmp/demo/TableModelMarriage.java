/*
 * File: TableModelMarriage.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JOptionPane;

import org.friendlysnmp.FColumn;
import org.friendlysnmp.FException;
import org.friendlysnmp.FID;
import org.friendlysnmp.FTable;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.TableRowAction;
import org.friendlysnmp.demo.mib.DemoTableMarriageMib;
import org.friendlysnmp.demo.mib.DemoTableMarriageMibFriend;
import org.friendlysnmp.event.FRestoreDefaultEvent;
import org.friendlysnmp.event.FRestoreDefaultListener;
import org.friendlysnmp.event.FTableGetListener;
import org.friendlysnmp.event.FTableSetListener;
import org.friendlysnmp.mib.RowStatusTC;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;

@SuppressWarnings("serial")
public class TableModelMarriage extends TableModelBase {

    private static class MarriageRow {
        // Populate with default values
        String husband;
        String wife;
        int year;
        String city;
        FID id;
        
        MarriageRow(FID id) {
            this.year = 0;
            this.city = "";
            this.id = id;
            // === Parse ID to text indices ===
            // NOTE: this format based on implied=false flag in 
            //       createID() OID.toSubIndex(false) call.
            // OID has format: length+content+length+content
            //                 <---husband--> <-----wife--->
            // Example: : 3.74.111.101.5.78.97.110.99.121 
            //            L.<---Joe-->.L.<-----Nancy---->
            //             \= 3 chars   \= 5 chars
            byte[] a = id.getBytes();
            int start = 0;
            husband = new String(a, start + 1, a[start]); // offset, length 
            start = husband.length() + 1;
            wife = new String(a, start + 1, a[start]); 
        }
        MarriageRow(String husband, String wife, int year, String city) {
            this.husband = husband;
            this.wife = wife;
            this.year = year;
            this.city = city;
            // === Create ID from text indices ===
            // (build row OID of two concatenated OIDs: sHusband+sWife)
            OID oidHusband = new OctetString(husband).toSubIndex(false);
            OID oidWife = new OctetString(wife).toSubIndex(false);
            OID oid = new OID(oidHusband);
            oid.append(oidWife);
            id = new FID(oid, husband + "+" + wife); // FID name only for pleasure
        }
        
        @Override
        public String toString() {
            return String.format("%s+%s %d %s", husband, wife, year, city); 
        }
    } // inner class MarriageRow
    
    // Column indices
    final static public int COL_HUSBAND = 0;
    final static public int COL_WIFE    = 1;
    final static public int COL_YEAR    = 2;
    final static public int COL_CITY    = 3;
    final static private int COL_LAST   = 4;

    // Column header names
    final static private String[] HEADERS = new String[COL_LAST];
    static {
        HEADERS[COL_HUSBAND] = "Husband (index)";
        HEADERS[COL_WIFE   ] = "Wife (index)";
        HEADERS[COL_YEAR   ] = "Year";
        HEADERS[COL_CITY   ] = "City";
    }

    private List<MarriageRow> lstRows;

    @Override
    public void initSNMP(FriendlyAgent agent) throws FException {
        lstRows = new ArrayList<MarriageRow>();
        fillDefaultContent();
        
        DemoTableMarriageMibFriend mib = new DemoTableMarriageMibFriend();
        agent.addMIB(mib);
        
        table = mib.getMarriageEntry();
        table.setVolatile(false); // loads persistent value (if exist)
        if (table.isPersistLoaded()) {
            fillPersistContent(table);
        }
        table.addGetListener(new FTableGetListener() {
            @Override
            public void get(FTable table) {
                loadMarriageTable();
            }
        });
        table.addSetListener(new FTableSetListener() {
            @Override
            public void set(FTable table, FID idRow, FColumn col, TableRowAction action) {
                updateMarriageTable(idRow, col, action);
            }
        });
        table.addRestoreDefaultListener(new FRestoreDefaultListener() {
            @Override
            public void restoreDefault(FRestoreDefaultEvent ev)
            {
                fillDefaultContent();                
                fireTableDataChanged();
            }
        });
    } // initSNMP()

    private void fillPersistContent(FTable table) {
        lstRows.clear();
        try {
            for (int r = 0;  r < table.getRowCount();  r++) {
                FID idRow = table.getRowID(r);
                MarriageRow row = new MarriageRow(idRow);
                row.city = table.getValueAt(idRow, 
                        DemoTableMarriageMibFriend.COLUMN_MarriageCity).toString();
                row.year = (Integer)table.getValueAt(idRow, 
                        DemoTableMarriageMibFriend.COLUMN_MarriageYear);
                lstRows.add(row);
            }
        } catch (FException e) {
        }
        sortRows();        
    }    
    private void fillDefaultContent() {
        lstRows.clear();
        fillRow("Joe",   "Nancy",  1988, "Boston");
        fillRow("John",  "Kathy",  1998, "Paris");
        fillRow("Jeff",  "Anna",   2002, "London");
        fillRow("Chris", "Martha", 1976, "New York");
        sortRows();        
    }
    
    private void fillRow(String husband, String wife, int year, String city) {
        MarriageRow row = new MarriageRow(husband, wife, year, city);
        int n = getRowIndex(row.id); 
        if (n >= 0) {
            return; // no duplicates 
        }
        lstRows.add(row);
        sortRows();        
    } // fillRow()    
    
    public int getColumnCount() {
        // Implements AbstractTableModel
        return HEADERS.length;
    }

    @Override
    public Class<?> getColumnClass(int c) {
        return getValueAt(0, c).getClass(); // to render and edit Integer
    }
    
    @Override
    public String getColumnName(int c) {
        table.getColumnCount();
        return HEADERS[c];
    }
    
    public int getRowCount() {
        // Implements AbstractTableModel
        return lstRows.size();
    }

    @Override
    public boolean isCellEditable(int indexRow, int indexCol) {
        switch (indexCol) {
            case COL_HUSBAND:
            case COL_WIFE: 
                return false;
            case COL_YEAR:
            case COL_CITY:
                return true;
            default: 
                throw new IllegalArgumentException("Not valid column: " + indexCol);
        }
    } // isCellEditable()
    
    public Object getValueAt(int r, int c) {
        // Implements AbstractTableModel
        MarriageRow row = lstRows.get(r);
        switch (c) {
            case COL_HUSBAND:
                return row.husband;
            case COL_WIFE: 
                return row.wife;
            case COL_YEAR:
                return row.year;
            case COL_CITY:
                return row.city;
            default: 
                throw new IllegalArgumentException("Not valid column: " + c);
        }
    } // getValueAt()

    @Override
    public void setValueAt(Object val, int r, int c) {
        if (r < 0  ||  r >= lstRows.size()) {
            // See notes in TableModelFlight.setValueAt().
            // This exception is for setting cell value before row is created.
            throw new IllegalArgumentException(String.format(
                    "Not valid row %d column %d value '%s'", r, c, val));
        }
        MarriageRow row = lstRows.get(r);
        switch (c) {
            case COL_YEAR:
                row.year = (Integer)val;
                row.year = Math.abs(row.year);
                break;
            case COL_CITY:
                row.city = (String)val;
                break;
            default: 
                throw new IllegalArgumentException("Not valid column: " + c);
        }
    } // setValueAt()
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int addRow() {
        // Call from UI
        String husband = JOptionPane.showInputDialog(
                    null,
                    "Enter husband's name:",
                    "Index-1",
                    JOptionPane.PLAIN_MESSAGE);
        if (husband == null  ||  husband.trim().length() == 0) {
            return -1; // no selection in the table
        }
        String wife = JOptionPane.showInputDialog(
                null,
                "Enter wife's name:",
                "Index-2",
                JOptionPane.PLAIN_MESSAGE);
        if (wife == null  ||  wife.trim().length() == 0) {
            return -1; // no selection in the table
        }
        MarriageRow row = new MarriageRow(husband, wife, 2000, "?");
        lstRows.add(row);
        sortRows();
        return getRowIndex(row.id);
    } // addRow()

    @Override
    public int deleteRow(int indexRow) {
        // Call from UI
        lstRows.remove(indexRow);
        if (indexRow >= lstRows.size()) {
            indexRow--;
        }
        return indexRow;
    } // deleteRow()

    private void loadMarriageTable() {
        // Call from agent on GET action in MIB browser.
        try {
            table.deleteAll();
            for (MarriageRow row : lstRows) {
                FID idRow = table.addRow(row.id);
                table.setValueAt(row.year,    
                        idRow, DemoTableMarriageMibFriend.COLUMN_MarriageYear);
                table.setValueAt(row.city,    
                        idRow, DemoTableMarriageMibFriend.COLUMN_MarriageCity);
                table.setValueAt(
                        RowStatusTC.active, 
                        idRow, DemoTableMarriageMibFriend.COLUMN_MarriageRowStatus);
            }
        } catch (FException e) {
            ErrorPresenter.showError(e,
                    "Failure to update table %s", table.getFIDtoString());
        }
    } // loadMarriageTable()
    
    private void updateMarriageTable(FID idRow, FColumn col, TableRowAction action) {
        // Call from agent on SET action in MIB browser.
        // NOTE. Row index in table does not match indexRow in lstRows:
        //   - table object does not have this row after DELETE action.
        //   - table object already has a new row for CREATE action.
        int indexRow = getRowIndex(idRow);
        try {
            switch (action) {
                case ROW_CHANGE:
                    Object obj = table.getValueAt(idRow, col);
                    if (indexRow >= 0) {
                        setValueAt(obj, indexRow, convertMibToColumn(col));
                    }
                    break;
                case ROW_CREATE:
                    lstRows.add(new MarriageRow(idRow));
                    sortRows();        
                    break;
                case ROW_DELETE:
                    lstRows.remove(indexRow);
                    break;
                default: 
                    throw new IllegalArgumentException("Not valid action: " + action);
            }
            fireTableDataChanged();
        } catch (FException e) {
            ErrorPresenter.showError(e,
                    "Failure to set value for cell for Row ID %s, Column %s", 
                    idRow, col);
        }
    } // updateMarriageTable()
    
    private int convertMibToColumn(FColumn col) {
        switch (col.getIndex_InTable()) {
            case DemoTableMarriageMib.idxMarriageYear: return COL_YEAR; 
            case DemoTableMarriageMib.idxMarriageCity: return COL_CITY; 
            default: 
                throw new IllegalArgumentException("Not valid column: " + col);
        }
    } // convertColumnToMib()

    private int getRowIndex(FID idRow) {
        for (int i = 0;  i < lstRows.size();  i++) {
            MarriageRow row = lstRows.get(i);
            if (row.id.equals(idRow)) {
                return i;
            }
        }
        return -1;
    } // getRowIndex()
    
    private void sortRows() {
        class MarriageRowComparator<T> implements Comparator<T> {
            public int compare(T o1, T o2) {
                MarriageRow row1 = (MarriageRow)o1;
                MarriageRow row2 = (MarriageRow)o2;
                return row1.id.compareTo(row2.id);
            }
        } // inner class MarriageRowComparator
        final MarriageRowComparator<MarriageRow> comp = 
            new MarriageRowComparator<MarriageRow>();  
        Collections.sort(lstRows, comp);
    } // sortRows()
    
} // class TableModelMarriage
