/*
 * File: Pane11Agent.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.friendlysnmp.FException;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.event.ShutdownListener;

@SuppressWarnings("serial")
public class Pane11Agent extends PaneBase 
implements ShutdownListener, ActionListener {
    
    private JCheckBox cbShutdown;
    private JButton btnStop;
    private JButton btnStart;
    private FriendlyAgent agent;
    
    @Override
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        cbShutdown = new JCheckBox("Allow remote shutdown from MIB browser");
        cbShutdown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateShutdown();
            }
        });
        panel.add(cbShutdown, BorderLayout.NORTH);
        
        JPanel panelBtn = new JPanel();
        btnStop  = createBtn(panelBtn, "Stop Agent");
        btnStart = createBtn(panelBtn, "Start Agent");
        panel.add(panelBtn, BorderLayout.SOUTH);
        updateEnable();
        
        return panel;
    } // getContentPanel()

    @Override
    protected void initSNMP(FriendlyAgent agent) {
        this.agent = agent;
    } // initSNMP()
    
    private JButton createBtn(JPanel panel, String label) {
        JButton btn = new JButton(label);
        btn.addActionListener(this);
        panel.add(btn);
        return btn;
    } // createBtn()

    private void updateShutdown() {
        if (cbShutdown.isSelected()) {
            agent.addShutdownListener(this);
        } else {
            agent.removeShutdownListener(this);
        }
    } // updateShutdown()
    
    @Override
    protected String getNotes() {
        return 
        " - Agent start / stop and remote shutdown demo." +
        "\n" +
        " - Use FRIENDLY-SNMP-MIB to send 'shutdown' command to the application" +
        " (scalar appEvents\\shutdownApp).";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Agent & Remote shutdown";
    } // getTitle()

    /**
     * This method is called when MIB browser sets shutdown request.
     * 
     * @see org.friendlysnmp.event.ShutdownListener#shutdownRequest()
     */
    @Override
    public boolean shutdownRequest() {
        // implements ShutdownListener
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to shutdown?",
                "Shutdown the demo",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            // Do not call System.exit() directly in the current thread
            // which belongs to the ThreadPool.
            // This will cause deadlock in org.snmp4j.util.ThreadPool
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    System.exit(0);
                }
            });
        }
        return false;
    } // shutdownRequest()

    private void updateEnable() {
        btnStop.setEnabled(agent.isRunning());
        btnStart.setEnabled(!agent.isRunning());
    }
    
    @Override
    public void actionPerformed(ActionEvent evt) {
        try {
            if (evt.getSource() == btnStop) {
                agent.stop();
            }
            if (evt.getSource() == btnStart) {
                agent.start();
            }
            updateEnable();
        } catch (FException e) {
            ErrorPresenter.showError(e, "Failure to stop/start SNMP agent");
        }
    }
    
} // class Pane11Agent
