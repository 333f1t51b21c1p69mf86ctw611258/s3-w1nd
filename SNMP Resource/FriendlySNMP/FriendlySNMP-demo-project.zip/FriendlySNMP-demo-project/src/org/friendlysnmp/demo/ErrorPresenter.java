/*
 * File: ErrorPresenter.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import javax.swing.JOptionPane;

import org.friendlysnmp.ThrowableFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ErrorPresenter {
    private static final Logger logger = LoggerFactory.getLogger(ErrorPresenter.class);

    public static String MSG_GENERIC = 
        "Application encountered a problem.\n"
      + "Notify administrator and restart application.";

    public final static String MSG_UNCAUGHT_EXCEPTION = 
        "Uncaught exception. Please restart application.";

    public static void showError(Throwable e) {
        showError(ThrowableFormatter.format((String)null, e));
    } // showError()

    public static void showError(Throwable e, String format, Object...args) {
        String msg;
        if (format == null) {
            msg = ThrowableFormatter.format(e);
        } else {
            msg = ThrowableFormatter.format(String.format(format, args), e);
        }
        logger.error(msg);
        showError(msg);
    } // showError()

    public static synchronized void showError(String error) {
        JOptionPane.showMessageDialog(
                null, // frame 
                error, 
                "Error", 
                JOptionPane.ERROR_MESSAGE,
                null); // icon not in a title, but instead of nice 
                       // default error icon in a body of popup
    } // showError()

} // class ErrorPresenter
