/*
 * File: TableModelBase.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumnModel;

import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.FException;
import org.friendlysnmp.FTable;

@SuppressWarnings("serial")
public abstract class TableModelBase extends AbstractTableModel {

    protected FTable table;

    public abstract void initSNMP(FriendlyAgent agent) throws FException;
    
    protected void setColumnFixedWidth(TableColumnModel columnModel, 
            int col, int width) 
    {
        columnModel.getColumn(col).setMaxWidth(width);
        columnModel.getColumn(col).setMinWidth(width);
    } // setColumnFixedWidth()
    
    public void updateColumnModel(TableColumnModel columnModel) {
        // Default does nothing
    } // updateColumnModel()
    
    /**
     * @return row index for new row (used for selection)
     * @throws FException
     */
    public abstract int addRow() throws FException;
    
    /**
     * @return row index for new suggested row selection
     * @throws FException
     */
    public abstract int deleteRow(int indexRow) throws FException;
    
} // class TableModelBase
