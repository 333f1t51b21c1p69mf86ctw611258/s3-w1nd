/*
 * File: Pane07Notification.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import org.friendlysnmp.FException;
import org.friendlysnmp.FNotification;
import org.friendlysnmp.FriendlyAgent;
import org.friendlysnmp.demo.mib.DemoNotifyWeatherMibFriend;

@SuppressWarnings("serial")
public class Pane07Notification extends PaneBase {

    private enum WeatherEnum { 
        Sunny,
        Cloudy,
        Rain,
        Snow;
        static WeatherEnum find(String name) {
            for (WeatherEnum w : values()) {
                if (w.name().equals(name)) {
                    return w;
                }
            }
            return null;
        }
    } // enum WeatherEnum
    
    private DemoNotifyWeatherMibFriend mib;
    private JRadioButton[] radioWeather;
    
    @Override
    protected void initSNMP(FriendlyAgent agent) throws FException {
        mib = new DemoNotifyWeatherMibFriend();
        agent.addMIB(mib);
    } // initSNMP()

    @Override
    protected JPanel getContentPanel() {
        radioWeather = new JRadioButton[] {
                new JRadioButton(WeatherEnum.Sunny.name(), true), 
                new JRadioButton(WeatherEnum.Cloudy.name()), 
                new JRadioButton(WeatherEnum.Rain.name()), 
                new JRadioButton(WeatherEnum.Snow.name()), 
        };
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        // Radio
        JPanel panelRadio = new JPanel();
        panel.add(panelRadio, BorderLayout.NORTH);
        panelRadio.setLayout(new GridLayout(radioWeather.length, 1)); // rows, cols
        panelRadio.setBorder(BorderFactory.createEmptyBorder(3, 20, 3, 0));
        ButtonGroup groupBtn = new ButtonGroup();
        for (JRadioButton radio : radioWeather) {
            panelRadio.add(radio);
            groupBtn.add(radio);
        }
        // Button
        JPanel panelBtn = new JPanel();
        panel.add(panelBtn, BorderLayout.SOUTH);
        JButton btn = new JButton("Send Notification");
        btn.setEnabled(FNotification.NOTIFY_ENABLED);
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendNotification();
            }
        });
        panelBtn.add(btn);
        return panel;
    } // getContentPanel()
    
    private void sendNotification() {
        WeatherEnum weather = null;
        for (JRadioButton btn : radioWeather) {
            if (btn.isSelected()) {
                weather = WeatherEnum.find(btn.getText());
                break;
            }
        }
        if (weather != null) {
            switch (weather) {
                case Sunny:
                    mib.getWeatherSunny().sendNotification();
                    break;
                case Cloudy:
                    mib.getWeatherCloudy().sendNotification();
                    break;
                case Rain:
                    mib.getWeatherRain().sendNotification(new Object[] {
                            "Put on raincoat.",
                            "Don't forget umbrella."
                    });
                    break;
                case Snow:
                    mib.getWeatherSnow().sendNotification();
                    break;
            }
        }
    } // sendNotification()
    
    @Override
    protected String getNotes() {
        return
        " - Notifications demo. Use DEMO-NOTIFY-WEATHER-MIB " +
        "to view these notifications in the MIB browser. " +
        "\n" +
        " - Notification 'rain' has additional parameters.";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Notifications";
    } // getTitle()
    
} // class Pane07Notification
