 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoTableUrlMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoTableUrlMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoTableUrlMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,3 });

  // Identities
  // Scalars
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DISPLAYSTRING = "DisplayString";

  // Scalars

  // Tables
  public static final OID oidUrlEntry = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,3,1,13,1 });

  // Index OID definitions
  public static final OID oidUrlIndex =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,3,1,13,1,1 });

  // Column TC definitions for urlEntry:
  public static final String tcModuleSNMPv2Tc = "SNMPv2-TC";
  public static final String tcDefDisplayString = "DisplayString";
    
  // Column sub-identifier definitions for urlEntry:
  public static final int colUrlHostName = 2;
  public static final int colUrlIpAddress = 3;
  public static final int colUrlResponseTime = 4;

  // Column index definitions for urlEntry:
  public static final int idxUrlHostName = 0;
  public static final int idxUrlIpAddress = 1;
  public static final int idxUrlResponseTime = 2;

  private MOTableSubIndex[] urlEntryIndexes;
  private MOTableIndex urlEntryIndex;
  
  private MOTable<UrlEntryRow,
                  MOColumn,
                  MOTableModel<UrlEntryRow>> urlEntry;
  private MOTableModel<UrlEntryRow> urlEntryModel;


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoTableUrlMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoTableUrlMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoTableUrlMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoTableUrlMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    createUrlEntry(moFactory);
  }



  public MOTable<UrlEntryRow,MOColumn,MOTableModel<UrlEntryRow>> getUrlEntry() {
    return urlEntry;
  }


  @SuppressWarnings(value={"unchecked"})
  private void createUrlEntry(MOFactory moFactory) {
    // Index definition
    urlEntryIndexes = 
      new MOTableSubIndex[] {
      moFactory.createSubIndex(oidUrlIndex, 
                               SMIConstants.SYNTAX_INTEGER, 1, 1)    };

    urlEntryIndex = 
      moFactory.createIndex(urlEntryIndexes,
                            false,
                            new MOTableIndexValidator() {
      public boolean isValidIndex(OID index) {
        boolean isValidIndex = true;
     //--AgentGen BEGIN=urlEntry::isValidIndex
     //--AgentGen END
        return isValidIndex;
      }
    });

    // Columns
    MOColumn[] urlEntryColumns = new MOColumn[3];
    urlEntryColumns[idxUrlHostName] = 
      moFactory.createColumn(colUrlHostName, 
                             SMIConstants.SYNTAX_OCTET_STRING,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY),
                             tcModuleSNMPv2Tc,
                             tcDefDisplayString);
    urlEntryColumns[idxUrlIpAddress] = 
      moFactory.createColumn(colUrlIpAddress, 
                             SMIConstants.SYNTAX_IPADDRESS,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY));
    urlEntryColumns[idxUrlResponseTime] = 
      moFactory.createColumn(colUrlResponseTime, 
                             SMIConstants.SYNTAX_GAUGE32,
                             moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_ONLY));
    // Table model
    urlEntryModel = (MOTableModel<UrlEntryRow>)
      moFactory.createTableModel(oidUrlEntry,
                                 urlEntryIndex,
                                 urlEntryColumns);
    ((MOMutableTableModel<UrlEntryRow>)urlEntryModel).setRowFactory(
      new UrlEntryRowFactory());
    urlEntry = 
      moFactory.createTable(oidUrlEntry,
                            urlEntryIndex,
                            urlEntryColumns,
                            urlEntryModel);
  }



  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.urlEntry, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.urlEntry, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars

  // Value Validators


  // Rows and Factories

  public class UrlEntryRow extends DefaultMOMutableRow2PC {

     //--AgentGen BEGIN=urlEntry::RowMembers
     //--AgentGen END

    public UrlEntryRow(OID index, Variable[] values) {
      super(index, values);
     //--AgentGen BEGIN=urlEntry::RowConstructor
     //--AgentGen END
    }
    
    public OctetString getUrlHostName() {
     //--AgentGen BEGIN=urlEntry::getUrlHostName
     //--AgentGen END
      return (OctetString) super.getValue(idxUrlHostName);
    }  
    
    public void setUrlHostName(OctetString newValue) {
     //--AgentGen BEGIN=urlEntry::setUrlHostName
     //--AgentGen END
      super.setValue(idxUrlHostName, newValue);
    }
    
    public IpAddress getUrlIpAddress() {
     //--AgentGen BEGIN=urlEntry::getUrlIpAddress
     //--AgentGen END
      return (IpAddress) super.getValue(idxUrlIpAddress);
    }  
    
    public void setUrlIpAddress(IpAddress newValue) {
     //--AgentGen BEGIN=urlEntry::setUrlIpAddress
     //--AgentGen END
      super.setValue(idxUrlIpAddress, newValue);
    }
    
    public UnsignedInteger32 getUrlResponseTime() {
     //--AgentGen BEGIN=urlEntry::getUrlResponseTime
     //--AgentGen END
      return (UnsignedInteger32) super.getValue(idxUrlResponseTime);
    }  
    
    public void setUrlResponseTime(UnsignedInteger32 newValue) {
     //--AgentGen BEGIN=urlEntry::setUrlResponseTime
     //--AgentGen END
      super.setValue(idxUrlResponseTime, newValue);
    }
    
    public Variable getValue(int column) {
     //--AgentGen BEGIN=urlEntry::RowGetValue
     //--AgentGen END
      switch(column) {
        case idxUrlHostName: 
        	return getUrlHostName();
        case idxUrlIpAddress: 
        	return getUrlIpAddress();
        case idxUrlResponseTime: 
        	return getUrlResponseTime();
        default:
          return super.getValue(column);
      }
    }
    
    public void setValue(int column, Variable value) {
     //--AgentGen BEGIN=urlEntry::RowSetValue
     //--AgentGen END
      switch(column) {
        case idxUrlHostName: 
        	setUrlHostName((OctetString)value);
        	break;
        case idxUrlIpAddress: 
        	setUrlIpAddress((IpAddress)value);
        	break;
        case idxUrlResponseTime: 
        	setUrlResponseTime((UnsignedInteger32)value);
        	break;
        default:
          super.setValue(column, value);
      }
    }

     //--AgentGen BEGIN=urlEntry::Row
     //--AgentGen END
  }
  
  class UrlEntryRowFactory 
        implements MOTableRowFactory<UrlEntryRow>
  {
    public synchronized UrlEntryRow createRow(OID index, Variable[] values)
        throws UnsupportedOperationException 
    {
      UrlEntryRow row = 
        new UrlEntryRow(index, values);
     //--AgentGen BEGIN=urlEntry::createRow
     //--AgentGen END
      return row;
    }
    
    public synchronized void freeRow(UrlEntryRow row) {
     //--AgentGen BEGIN=urlEntry::freeRow
     //--AgentGen END
    }

     //--AgentGen BEGIN=urlEntry::RowFactory
     //--AgentGen END
  }


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoTableUrlMib
  protected void addTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


