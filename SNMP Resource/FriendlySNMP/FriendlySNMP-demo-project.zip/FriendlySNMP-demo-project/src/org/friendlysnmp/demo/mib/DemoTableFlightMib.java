 
//--AgentGen BEGIN=_BEGIN
package org.friendlysnmp.demo.mib;
//--AgentGen END

import org.snmp4j.smi.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.agent.*;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp.smi.*;
import org.snmp4j.agent.request.*;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogAdapter;
import org.snmp4j.agent.mo.snmp.tc.*;


//--AgentGen BEGIN=_IMPORT
@SuppressWarnings({"unused", "rawtypes"})
//--AgentGen END

public class DemoTableFlightMib 
//--AgentGen BEGIN=_EXTENDS
//--AgentGen END
implements MOGroup 
//--AgentGen BEGIN=_IMPLEMENTS
//--AgentGen END
{

  private static final LogAdapter LOGGER = 
      LogFactory.getLogger(DemoTableFlightMib.class);

//--AgentGen BEGIN=_STATIC
//--AgentGen END

  // Factory
  private MOFactory moFactory = 
    DefaultMOFactory.getInstance();

  // Constants 

  /**
   * OID of this MIB module for usage which can be 
   * used for its identification.
   */
  public static final OID oidDemoTableFlightMib =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,4 });

  // Identities
  // Scalars
  // Tables

  // Notifications

  // Enumerations




  // TextualConventions
  private static final String TC_MODULE_DEMO_TABLE_FLIGHT_MIB = "DEMO-TABLE-FLIGHT-MIB";
  private static final String TC_MODULE_SNMPV2_TC = "SNMPv2-TC";
  private static final String TC_DEMOFLIGHTSTATUSTC = "DemoFlightStatusTC";
  private static final String TC_DEMOFLIGHTNUMBERTC = "DemoFlightNumberTC";
  private static final String TC_DISPLAYSTRING = "DisplayString";
  private static final String TC_ROWSTATUS = "RowStatus";

  // Scalars

  // Tables
  public static final OID oidFlightEntry = 
    new OID(new int[] { 1,3,6,1,4,1,29091,10,4,1,13,1 });

  // Index OID definitions
  public static final OID oidFlightIndex =
    new OID(new int[] { 1,3,6,1,4,1,29091,10,4,1,13,1,2 });

  // Column TC definitions for flightEntry:
  public static final String tcModuleSNMPv2Tc = "SNMPv2-TC";
  public static final String tcDefDisplayString = "DisplayString";
  public static final String tcModuleDemoTableFlightMib = "DEMO-TABLE-FLIGHT-MIB";
  public static final String tcDefDemoFlightNumberTC = "DemoFlightNumberTC";
  public static final String tcDefDemoFlightStatusTC = "DemoFlightStatusTC";
  public static final String tcDefRowStatus = "RowStatus";
    
  // Column sub-identifier definitions for flightEntry:
  public static final int colFlightCarrier = 10;
  public static final int colFlightNumber = 14;
  public static final int colFlightDestination = 20;
  public static final int colFlightDepartTime = 25;
  public static final int colFlightStatus = 33;
  public static final int colFlightRowStatus = 40;

  // Column index definitions for flightEntry:
  public static final int idxFlightCarrier = 0;
  public static final int idxFlightNumber = 1;
  public static final int idxFlightDestination = 2;
  public static final int idxFlightDepartTime = 3;
  public static final int idxFlightStatus = 4;
  public static final int idxFlightRowStatus = 5;

  private MOTableSubIndex[] flightEntryIndexes;
  private MOTableIndex flightEntryIndex;
  
  private MOTable<FlightEntryRow,
                  MOColumn,
                  MOTableModel<FlightEntryRow>> flightEntry;
  private MOTableModel<FlightEntryRow> flightEntryModel;


//--AgentGen BEGIN=_MEMBERS
//--AgentGen END

  /**
   * Constructs a DemoTableFlightMib instance without actually creating its
   * <code>ManagedObject</code> instances. This has to be done in a
   * sub-class constructor or after construction by calling 
   * {@link #createMO(MOFactory moFactory)}. 
   */
  protected DemoTableFlightMib() {
//--AgentGen BEGIN=_DEFAULTCONSTRUCTOR
//--AgentGen END
  }

  /**
   * Constructs a DemoTableFlightMib instance and actually creates its
   * <code>ManagedObject</code> instances using the supplied 
   * <code>MOFactory</code> (by calling
   * {@link #createMO(MOFactory moFactory)}).
   * @param moFactory
   *    the <code>MOFactory</code> to be used to create the
   *    managed objects for this module.
   */
  public DemoTableFlightMib(MOFactory moFactory) {
  	this();
    createMO(moFactory);
//--AgentGen BEGIN=_FACTORYCONSTRUCTOR
//--AgentGen END
  }

//--AgentGen BEGIN=_CONSTRUCTORS
//--AgentGen END

  /**
   * Create the ManagedObjects defined for this MIB module
   * using the specified {@link MOFactory}.
   * @param moFactory
   *    the <code>MOFactory</code> instance to use for object 
   *    creation.
   */
  protected void createMO(MOFactory moFactory) {
    addTCsToFactory(moFactory);
    createFlightEntry(moFactory);
  }



  public MOTable<FlightEntryRow,MOColumn,MOTableModel<FlightEntryRow>> getFlightEntry() {
    return flightEntry;
  }


  @SuppressWarnings(value={"unchecked"})
  private void createFlightEntry(MOFactory moFactory) {
    // Index definition
    flightEntryIndexes = 
      new MOTableSubIndex[] {
      moFactory.createSubIndex(oidFlightIndex, 
                               SMIConstants.SYNTAX_INTEGER, 1, 1)    };

    flightEntryIndex = 
      moFactory.createIndex(flightEntryIndexes,
                            false,
                            new MOTableIndexValidator() {
      public boolean isValidIndex(OID index) {
        boolean isValidIndex = true;
     //--AgentGen BEGIN=flightEntry::isValidIndex
     //--AgentGen END
        return isValidIndex;
      }
    });

    // Columns
    MOColumn[] flightEntryColumns = new MOColumn[6];
    flightEntryColumns[idxFlightCarrier] = 
      new DisplayString(colFlightCarrier,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint flightCarrierVC = new ConstraintsImpl();
    ((ConstraintsImpl)flightCarrierVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)flightEntryColumns[idxFlightCarrier]).
      addMOValueValidationListener(new ValueConstraintValidator(flightCarrierVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightCarrier]).
      addMOValueValidationListener(new FlightCarrierValidator());
    flightEntryColumns[idxFlightNumber] = 
      new MOMutableColumn<Integer32>(colFlightNumber,
                          SMIConstants.SYNTAX_INTEGER32,
                          moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                          (Integer32)null);
    ValueConstraint flightNumberVC = new ConstraintsImpl();
    ((ConstraintsImpl)flightNumberVC).add(new Constraint(0L, 999L));
    ((MOMutableColumn)flightEntryColumns[idxFlightNumber]).
      addMOValueValidationListener(new ValueConstraintValidator(flightNumberVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightNumber]).
      addMOValueValidationListener(new FlightNumberValidator());
    flightEntryColumns[idxFlightDestination] = 
      new DisplayString(colFlightDestination,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint flightDestinationVC = new ConstraintsImpl();
    ((ConstraintsImpl)flightDestinationVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)flightEntryColumns[idxFlightDestination]).
      addMOValueValidationListener(new ValueConstraintValidator(flightDestinationVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightDestination]).
      addMOValueValidationListener(new FlightDestinationValidator());
    flightEntryColumns[idxFlightDepartTime] = 
      new DisplayString(colFlightDepartTime,
                        moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                        (OctetString)null);
    ValueConstraint flightDepartTimeVC = new ConstraintsImpl();
    ((ConstraintsImpl)flightDepartTimeVC).add(new Constraint(0L, 255L));
    ((MOMutableColumn)flightEntryColumns[idxFlightDepartTime]).
      addMOValueValidationListener(new ValueConstraintValidator(flightDepartTimeVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightDepartTime]).
      addMOValueValidationListener(new FlightDepartTimeValidator());
    flightEntryColumns[idxFlightStatus] = 
      new MOMutableColumn<Integer32>(colFlightStatus,
                          SMIConstants.SYNTAX_INTEGER,
                          moFactory.createAccess(MOAccessImpl.ACCESSIBLE_FOR_READ_CREATE),
                          (Integer32)null);
    ValueConstraint flightStatusVC = new EnumerationConstraint(
      new int[] { 1,
                  4,
                  8,
                  12 });
    ((MOMutableColumn)flightEntryColumns[idxFlightStatus]).
      addMOValueValidationListener(new ValueConstraintValidator(flightStatusVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightStatus]).
      addMOValueValidationListener(new FlightStatusValidator());
    flightEntryColumns[idxFlightRowStatus] = 
      new RowStatus(colFlightRowStatus);
    ValueConstraint flightRowStatusVC = new EnumerationConstraint(
      new int[] { 1,
                  2,
                  3,
                  4,
                  5,
                  6 });
    ((MOMutableColumn)flightEntryColumns[idxFlightRowStatus]).
      addMOValueValidationListener(new ValueConstraintValidator(flightRowStatusVC));                                  
    ((MOMutableColumn)flightEntryColumns[idxFlightRowStatus]).
      addMOValueValidationListener(new FlightRowStatusValidator());
    // Table model
    flightEntryModel = (MOTableModel<FlightEntryRow>)
      moFactory.createTableModel(oidFlightEntry,
                                 flightEntryIndex,
                                 flightEntryColumns);
    ((MOMutableTableModel<FlightEntryRow>)flightEntryModel).setRowFactory(
      new FlightEntryRowFactory());
    flightEntry = 
      moFactory.createTable(oidFlightEntry,
                            flightEntryIndex,
                            flightEntryColumns,
                            flightEntryModel);
  }



  public void registerMOs(MOServer server, OctetString context) 
    throws DuplicateRegistrationException 
  {
    // Scalar Objects
    server.register(this.flightEntry, context);
//--AgentGen BEGIN=_registerMOs
//--AgentGen END
  }

  public void unregisterMOs(MOServer server, OctetString context) {
    // Scalar Objects
    server.unregister(this.flightEntry, context);
//--AgentGen BEGIN=_unregisterMOs
//--AgentGen END
  }

  // Notifications

  // Scalars

  // Value Validators

  /**
   * The <code>FlightCarrierValidator</code> implements the value
   * validation for <code>FlightCarrier</code>.
   */
  static class FlightCarrierValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=flightCarrier::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>FlightNumberValidator</code> implements the value
   * validation for <code>FlightNumber</code>.
   */
  static class FlightNumberValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      long v = ((Integer32)newValue).getValue();
      if (!(((v >= 0L) && (v <= 999L)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_VALUE);
        return;
      }
     //--AgentGen BEGIN=flightNumber::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>FlightDestinationValidator</code> implements the value
   * validation for <code>FlightDestination</code>.
   */
  static class FlightDestinationValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=flightDestination::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>FlightDepartTimeValidator</code> implements the value
   * validation for <code>FlightDepartTime</code>.
   */
  static class FlightDepartTimeValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
      OctetString os = (OctetString)newValue;
      if (!(((os.length() >= 0) && (os.length() <= 255)))) {
        validationEvent.setValidationStatus(SnmpConstants.SNMP_ERROR_WRONG_LENGTH);
        return;
      }
     //--AgentGen BEGIN=flightDepartTime::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>FlightStatusValidator</code> implements the value
   * validation for <code>FlightStatus</code>.
   */
  static class FlightStatusValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
     //--AgentGen BEGIN=flightStatus::validate
     //--AgentGen END
    }
  }
  /**
   * The <code>FlightRowStatusValidator</code> implements the value
   * validation for <code>FlightRowStatus</code>.
   */
  static class FlightRowStatusValidator implements MOValueValidationListener {
    
    public void validate(MOValueValidationEvent validationEvent) {
      Variable newValue = validationEvent.getNewValue();
     //--AgentGen BEGIN=flightRowStatus::validate
     //--AgentGen END
    }
  }

  // Rows and Factories

  public class FlightEntryRow extends DefaultMOMutableRow2PC {

     //--AgentGen BEGIN=flightEntry::RowMembers
     //--AgentGen END

    public FlightEntryRow(OID index, Variable[] values) {
      super(index, values);
     //--AgentGen BEGIN=flightEntry::RowConstructor
     //--AgentGen END
    }
    
    public OctetString getFlightCarrier() {
     //--AgentGen BEGIN=flightEntry::getFlightCarrier
     //--AgentGen END
      return (OctetString) super.getValue(idxFlightCarrier);
    }  
    
    public void setFlightCarrier(OctetString newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightCarrier
     //--AgentGen END
      super.setValue(idxFlightCarrier, newValue);
    }
    
    public Integer32 getFlightNumber() {
     //--AgentGen BEGIN=flightEntry::getFlightNumber
     //--AgentGen END
      return (Integer32) super.getValue(idxFlightNumber);
    }  
    
    public void setFlightNumber(Integer32 newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightNumber
     //--AgentGen END
      super.setValue(idxFlightNumber, newValue);
    }
    
    public OctetString getFlightDestination() {
     //--AgentGen BEGIN=flightEntry::getFlightDestination
     //--AgentGen END
      return (OctetString) super.getValue(idxFlightDestination);
    }  
    
    public void setFlightDestination(OctetString newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightDestination
     //--AgentGen END
      super.setValue(idxFlightDestination, newValue);
    }
    
    public OctetString getFlightDepartTime() {
     //--AgentGen BEGIN=flightEntry::getFlightDepartTime
     //--AgentGen END
      return (OctetString) super.getValue(idxFlightDepartTime);
    }  
    
    public void setFlightDepartTime(OctetString newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightDepartTime
     //--AgentGen END
      super.setValue(idxFlightDepartTime, newValue);
    }
    
    public Integer32 getFlightStatus() {
     //--AgentGen BEGIN=flightEntry::getFlightStatus
     //--AgentGen END
      return (Integer32) super.getValue(idxFlightStatus);
    }  
    
    public void setFlightStatus(Integer32 newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightStatus
     //--AgentGen END
      super.setValue(idxFlightStatus, newValue);
    }
    
    public Integer32 getFlightRowStatus() {
     //--AgentGen BEGIN=flightEntry::getFlightRowStatus
     //--AgentGen END
      return (Integer32) super.getValue(idxFlightRowStatus);
    }  
    
    public void setFlightRowStatus(Integer32 newValue) {
     //--AgentGen BEGIN=flightEntry::setFlightRowStatus
     //--AgentGen END
      super.setValue(idxFlightRowStatus, newValue);
    }
    
    public Variable getValue(int column) {
     //--AgentGen BEGIN=flightEntry::RowGetValue
     //--AgentGen END
      switch(column) {
        case idxFlightCarrier: 
        	return getFlightCarrier();
        case idxFlightNumber: 
        	return getFlightNumber();
        case idxFlightDestination: 
        	return getFlightDestination();
        case idxFlightDepartTime: 
        	return getFlightDepartTime();
        case idxFlightStatus: 
        	return getFlightStatus();
        case idxFlightRowStatus: 
        	return getFlightRowStatus();
        default:
          return super.getValue(column);
      }
    }
    
    public void setValue(int column, Variable value) {
     //--AgentGen BEGIN=flightEntry::RowSetValue
     //--AgentGen END
      switch(column) {
        case idxFlightCarrier: 
        	setFlightCarrier((OctetString)value);
        	break;
        case idxFlightNumber: 
        	setFlightNumber((Integer32)value);
        	break;
        case idxFlightDestination: 
        	setFlightDestination((OctetString)value);
        	break;
        case idxFlightDepartTime: 
        	setFlightDepartTime((OctetString)value);
        	break;
        case idxFlightStatus: 
        	setFlightStatus((Integer32)value);
        	break;
        case idxFlightRowStatus: 
        	setFlightRowStatus((Integer32)value);
        	break;
        default:
          super.setValue(column, value);
      }
    }

     //--AgentGen BEGIN=flightEntry::Row
     //--AgentGen END
  }
  
  class FlightEntryRowFactory 
        implements MOTableRowFactory<FlightEntryRow>
  {
    public synchronized FlightEntryRow createRow(OID index, Variable[] values)
        throws UnsupportedOperationException 
    {
      FlightEntryRow row = 
        new FlightEntryRow(index, values);
     //--AgentGen BEGIN=flightEntry::createRow
     //--AgentGen END
      return row;
    }
    
    public synchronized void freeRow(FlightEntryRow row) {
     //--AgentGen BEGIN=flightEntry::freeRow
     //--AgentGen END
    }

     //--AgentGen BEGIN=flightEntry::RowFactory
     //--AgentGen END
  }


//--AgentGen BEGIN=_METHODS
//--AgentGen END

  // Textual Definitions of MIB module DemoTableFlightMib
  protected void addTCsToFactory(MOFactory moFactory) {
   moFactory.addTextualConvention(new DemoFlightStatusTC()); 
   moFactory.addTextualConvention(new DemoFlightNumberTC()); 
  }


  public class DemoFlightStatusTC implements TextualConvention {
    public static final int boarding = 1;
    public static final int delayed = 4;
    public static final int departed = 8;
    public static final int canceled = 12;
  	
    public DemoFlightStatusTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_TABLE_FLIGHT_MIB;
    }
  	
    public String getName() {
      return TC_DEMOFLIGHTSTATUSTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
        ((AssignableFromLong)v).setValue(1);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoFlightStatusTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new EnumerationConstraint(
        new int[] { boarding,
                    delayed,
                    departed,
                    canceled });
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoFlightStatusTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new EnumerationConstraint(
          new int[] { boarding,
                      delayed,
                      departed,
                      canceled });
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoFlightStatusTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


  public class DemoFlightNumberTC implements TextualConvention {
  	
    public DemoFlightNumberTC() {
    }

    public String getModuleName() {
      return TC_MODULE_DEMO_TABLE_FLIGHT_MIB;
    }
  	
    public String getName() {
      return TC_DEMOFLIGHTNUMBERTC;
    }
    
    public Variable createInitialValue() {
    	Variable v = new Integer32();
      if (v instanceof AssignableFromLong) {
      	((AssignableFromLong)v).setValue(0L);
      }
    	// further modify value to comply with TC constraints here:
     //--AgentGen BEGIN=DemoFlightNumberTC::createInitialValue
     //--AgentGen END
	    return v;
    }
  	
    public MOScalar createScalar(OID oid, MOAccess access, Variable value) {
      MOScalar scalar = moFactory.createScalar(oid, access, value);
      ValueConstraint vc = new ConstraintsImpl();
      ((ConstraintsImpl)vc).add(new Constraint(0L, 999L));
      scalar.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
     //--AgentGen BEGIN=DemoFlightNumberTC::createScalar
     //--AgentGen END
      return scalar;
    }
  	
    public MOColumn createColumn(int columnID, int syntax, MOAccess access,
                                 Variable defaultValue, boolean mutableInService) {
      MOColumn col = moFactory.createColumn(columnID, syntax, access, 
                                            defaultValue, mutableInService);
      if (col instanceof MOMutableColumn) {
        MOMutableColumn mcol = (MOMutableColumn)col;
        ValueConstraint vc = new ConstraintsImpl();
        ((ConstraintsImpl)vc).add(new Constraint(0L, 999L));
        mcol.addMOValueValidationListener(new ValueConstraintValidator(vc));                                  
      }
     //--AgentGen BEGIN=DemoFlightNumberTC::createColumn
     //--AgentGen END
      return col;      
    }
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_BEGIN
//--AgentGen END

  // Textual Definitions of other MIB modules
  public void addImportedTCsToFactory(MOFactory moFactory) {
  }


//--AgentGen BEGIN=_TC_CLASSES_IMPORTED_MODULES_END
//--AgentGen END

//--AgentGen BEGIN=_CLASSES
//--AgentGen END

//--AgentGen BEGIN=_END
//--AgentGen END
}


