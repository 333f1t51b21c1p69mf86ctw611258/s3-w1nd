/*
 * File: Pane08Deadlock.java
 * 
 * Copyright (C) 2014 FriendlySNMP.org; All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *     
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package org.friendlysnmp.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

@SuppressWarnings("serial")
public class Pane08Deadlock extends PaneBase {

    private char chChainId = 'A';
    private JSpinner spinner;
    private JTextArea taConsole;
    private StringBuilder sbConsole;
    
    @Override
    protected JPanel getContentPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        
        // Spinner
        JPanel panelSpinner = new JPanel();
        panel.add(panelSpinner, BorderLayout.NORTH);
        panelSpinner.add(new JLabel("Number of deadlocked threads: "));
        SpinnerModel model = new SpinnerNumberModel(
                2,   // initial value
                2,   // min value
                100, // max value
                1);  // step
        spinner = new JSpinner(model);
        panelSpinner.add(spinner);

        // Console
        sbConsole = new StringBuilder(); // JTextArea.append() problem with '\n' 
        taConsole = new JTextArea();
        taConsole.setEditable(false);
        taConsole.setBackground(new Color(255,255,230));
        taConsole.setFont(FONT_CONSOLE);
        JScrollPane paneScroll = new JScrollPane(taConsole, 
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel.add(paneScroll, BorderLayout.CENTER);
        
        // Button
        JPanel panelBtn = new JPanel();
        panel.add(panelBtn, BorderLayout.SOUTH);
        JButton btn = new JButton("Make Deadlock");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                makeDeadlock();
            }
        });
        panelBtn.add(btn);
        return panel;
    } // getContentPanel()
    
    private void makeDeadlock() {
        if (chChainId > 'Z') {
            ErrorPresenter.showError(
                    "Deadlock was generated too many times.\n" +
                    "I am out of characters A..Z\n" +
                    "Sorry...");
            return;
        }
        int size = (Integer)spinner.getValue();
        int choice = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to create deadlock?\n\n"
                  + "Application will create " + size + " threads"
                  + " which will deadlock each other forever.\n"
                  + "You have to restart application to kill them.\n"
                  + "All other application functionality will remain intact.",
                "Deadlock creation",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }
        if (sbConsole.length() > 0) {
            addConsoleLine("\n");
        }
        addConsoleLine(String.format("Creating deadlock '%s'", chChainId));
        // Create threads
        ThisDeadlockThread[] ar = new ThisDeadlockThread[size];
        for (int i = 0;  i < size;  i++) {
            ar[i] = new ThisDeadlockThread(chChainId);
        }
        // Provide resources
        for (int i = 0;  i < size - 1;  i++) {
            ar[i].setNextResource(ar[i + 1].getOwnResource());
        }
        ar[size - 1].setNextResource(ar[0].getOwnResource());
        // Start threads
        for (int i = 0;  i < size;  i++) {
            ar[i].start();
        }
        chChainId++;
    } // makeDeadlock()
    
    synchronized private void addConsoleLine(String s) {
        sbConsole.append(s);
        if (!s.equals("\n")) {
            sbConsole.append('\n');
        }
        taConsole.setText(sbConsole.toString());
        taConsole.setCaretPosition(sbConsole.length());
    }
    
    @Override
    protected String getNotes() {
        return 
        " - Deadlock detection demo. " +
        "\n" +
        " - Create deadlock and check how deadlock is discovered and notification " +
        "is sent to the MIB browser. View deadlock details in the MIB browser " +
        "using FRIENDLY-SNMP-MIB.";
    } // getNotes()
    
    @Override
    protected String getTitle() {
        return "Deadlock detection";
    } // getTitle()
    
    class ThisDeadlockThread extends Thread {
        char chChainID;
        Object objOwnResource;
        Object objNextResource;
        ThisDeadlockThread(char chChainID) {
            this.chChainID = chChainID;
            objOwnResource = new Long(getId()); // do not use Long.valueOf(long)!!
        }
        Object getOwnResource() {
            return objOwnResource;
        }
        void setNextResource(Object objNextResource) {
            this.objNextResource = objNextResource;
            setName(String.format(
                    "Demo-%s-Deadlocked-%s-by-%s", 
                    chChainID, objOwnResource, objNextResource));
        }
        public void run() {
            addConsoleLine("Started thread " + getName());
            makeDeadlock(); // add one more element in stack trace...
            addConsoleLine(getName() + ": exit");
        }
        
        private void makeDeadlock() {
            synchronized (objOwnResource) {
                addConsoleLine(String.format(
                        "   locked resource '%s' %s@%s", 
                        objOwnResource, objOwnResource.getClass().getName(),
                        Integer.toHexString(System.identityHashCode(objOwnResource))));
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                }
                synchronized (objNextResource) {
                    addConsoleLine(String.format(
                            "Thread %s: locked next resource '%s'",
                            getName(), objNextResource));
                }
            }
        }
    } // inner class ThisDeadlockThread
    
} // class Pane08Deadlock
