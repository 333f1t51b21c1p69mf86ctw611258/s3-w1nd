This folder contains libraries required for FriendlySNMP-demo:
   - FriendlySNMP-XX.jar
   - log4j-xxx.jar
   - SNMP4J-xxx.jar
   - SNMP4J-agent-xxx.jar
All these libraries are NOT in CVS. They are copied fresh by mgUpdateLib.xml

Do not edit 'versions.properties'!! This is a copy from FriendlySNMP-lib/lib.