HowTo setup the project in Eclipse environment.
-----------------------------------------------
1. Unzip FriendlySNMP-demo-project
2. Create new Eclipse project "FriendlySNMP-demo" from existing source in 
the folder with unzipped files.
3. The project contains ready to use launch configuration "DemoFriendly.launch"
Note, this launch configuration has "config" folder added to the classpath.
The application uses classpath to find properties files.
